package ru.pulse.omnitest;
import android.content.Context;
import org.json.*;
final class LocalPlanner {
 private static JSONObject load(Context c)throws Exception{
  Vault vault=new Vault(c);String raw=vault.read("planner-state");if(!raw.isEmpty())return new JSONObject(raw);
  String legacy=vault.read("github-data");JSONObject base=legacy.isEmpty()?PlannerEngine.empty():PlannerEngine.validate(new JSONObject(legacy));JSONArray ops=new JSONArray();String pending=vault.read("pending-completions");
  if(!pending.isEmpty()){JSONArray list=new JSONArray(pending);for(int i=0;i<list.length();i++)ops.put(PlannerEngine.operation(new JSONObject().put("kind","complete").put("taskId",list.getJSONObject(i).getString("taskId")).put("date",list.getJSONObject(i).getString("date")).put("done",true)));}
  JSONObject state=new JSONObject().put("base",base).put("ops",ops).put("conflicts",new JSONArray());save(c,state);return state;
 }
 private static void save(Context c,JSONObject state)throws Exception{new Vault(c).save("planner-state",state.toString());}
 static synchronized JSONObject snapshot(Context c)throws Exception{return PlannerEngine.copy(load(c));}
 static synchronized JSONObject view(Context c)throws Exception{return PlannerEngine.view(load(c));}
 static synchronized JSONObject enqueue(Context c,JSONObject change)throws Exception{
  JSONObject state=load(c),op=PlannerEngine.operation(change),view=PlannerEngine.view(state);
  PlannerEngine.apply(view,op,false);if(state.getJSONArray("ops").length()>=1000)throw new Exception("Сначала отправьте накопленные изменения в GitHub.");
  state.getJSONArray("ops").put(op);save(c,state);return PlannerEngine.view(state);
 }
 static synchronized void accept(Context c,JSONObject remote,JSONArray ack,JSONArray conflicts)throws Exception{save(c,PlannerEngine.accept(load(c),remote,ack,conflicts));}
 static synchronized void initial(Context c,JSONObject remote)throws Exception{
  JSONObject state=load(c);if(state.getJSONArray("ops").length()>0)throw new Exception("Сначала отправьте локальные правки прежнего подключения.");
  save(c,state.put("base",PlannerEngine.validate(remote)).put("ops",new JSONArray()).put("conflicts",new JSONArray()));
 }
 static synchronized void snapshot(Context c,JSONObject mobile)throws Exception{mobile.getJSONArray("branches");java.time.Instant timestamp=java.time.Instant.parse(mobile.getString("capturedAt"));JSONObject state=load(c),old=state.optJSONObject("mobilePending");if(old==null||timestamp.isAfter(java.time.Instant.parse(old.getString("capturedAt")))){state.put("mobilePending",mobile);save(c,state);}}
 static synchronized void resolve(Context c,String id,boolean keepLocal)throws Exception{save(c,PlannerEngine.resolve(load(c),id,keepLocal));}
}
