package ru.pulse.omnitest;
import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.*;
import javax.crypto.spec.*;
public final class CryptoCore {
 public static final int ROUNDS=600000;
 public static String b64(byte[] b){return Base64.getEncoder().encodeToString(b);}
 public static byte[] bytes(String s){return Base64.getDecoder().decode(s);}
 public static byte[] random(int n){byte[] b=new byte[n];new SecureRandom().nextBytes(b);return b;}
 private static SecretKeySpec key(String phrase,byte[] salt)throws Exception{PBEKeySpec spec=new PBEKeySpec(phrase.toCharArray(),salt,ROUNDS,256);try{return new SecretKeySpec(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded(),"AES");}finally{spec.clearPassword();}}
 public static byte[] encrypt(byte[] data,String phrase,byte[] salt,byte[] iv)throws Exception{Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key(phrase,salt),new GCMParameterSpec(128,iv));c.updateAAD("pulse/vault/v1".getBytes("UTF-8"));return c.doFinal(data);}
 public static byte[] decrypt(byte[] data,String phrase,byte[] salt,byte[] iv)throws Exception{if(salt.length!=16||iv.length!=12||data.length>1200000)throw new IllegalArgumentException("Invalid envelope");Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(phrase,salt),new GCMParameterSpec(128,iv));c.updateAAD("pulse/vault/v1".getBytes("UTF-8"));return c.doFinal(data);}
}
