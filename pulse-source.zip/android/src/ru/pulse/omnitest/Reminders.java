package ru.pulse.omnitest;
import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import org.json.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

final class Reminders {
 static final ZoneId ZONE=ReminderRules.ZONE;
 private static final int LIMIT=128;
 static boolean exact(Context c){return Build.VERSION.SDK_INT<31||c.getSystemService(AlarmManager.class).canScheduleExactAlarms();}
 static String tag(String id,String date){return id+"|"+date;}
 static boolean occurs(JSONObject task,LocalDate date)throws Exception{return ReminderRules.occurs(task.getString("date"),task.getString("repeat"),date);}
 static boolean done(Context c,JSONObject data,String id,String date)throws Exception{
  for(JSONArray list:new JSONArray[]{data.getJSONArray("completions"),GitHubSync.pending(c)})for(int i=0;i<list.length();i++){
   JSONObject v=list.getJSONObject(i);if(id.equals(v.getString("taskId"))&&date.equals(v.getString("date")))return true;
  }
  return false;
 }
 static void channel(Context c){c.getSystemService(NotificationManager.class).createNotificationChannel(new NotificationChannel("tasks","Напоминания о своих делах",NotificationManager.IMPORTANCE_HIGH));}
 private static PendingIntent intent(Context c,String id,String date,long due){
  Intent i=new Intent(c,ReminderReceiver.class).setAction("ru.pulse.REMIND").setData(Uri.parse("pulse://remind/"+Uri.encode(id)+"/"+date)).putExtra("id",id).putExtra("date",date).putExtra("due",due);
  return PendingIntent.getBroadcast(c,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
 }
 private static void schedule(Context c,long due,PendingIntent pi){
  AlarmManager alarms=c.getSystemService(AlarmManager.class);
  if(exact(c))alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,due,pi);else alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,due,pi);
 }
 static synchronized void rebuild(Context c){
  try{
   // Validate cached data before cancelling the previous alarms.
   JSONObject data=GitHubSync.local(c);Set<String> completed=new HashSet<>();
   for(JSONArray list:new JSONArray[]{data.getJSONArray("completions"),GitHubSync.pending(c)})for(int i=0;i<list.length();i++){
    JSONObject v=list.getJSONObject(i);completed.add(tag(v.getString("taskId"),v.getString("date")));
   }
   JSONArray tasks=data.getJSONArray("tasks");List<JSONObject> upcoming=new ArrayList<>();long now=System.currentTimeMillis();int withReminders=0;
   for(int i=0;i<tasks.length();i++){
    JSONObject t=tasks.getJSONObject(i);if(t.isNull("reminder"))continue;withReminders++;String id=t.getString("id");
    for(ReminderRules.Entry e:ReminderRules.upcoming(t.getString("date"),t.getString("time"),t.getString("repeat"),t.getInt("reminder"),now,day->completed.contains(tag(id,day.toString()))))
     upcoming.add(new JSONObject().put("id",id).put("date",e.date.toString()).put("due",e.due));
   }
   upcoming.sort((a,b)->Long.compare(a.optLong("due"),b.optLong("due")));
   AlarmManager alarms=c.getSystemService(AlarmManager.class);JSONArray old=new JSONArray(c.getSharedPreferences("alarms",0).getString("scheduled","[]"));
   for(int i=0;i<old.length();i++){
    JSONObject e=old.getJSONObject(i);PendingIntent pi=intent(c,e.getString("id"),e.getString("date"),e.getLong("due"));alarms.cancel(pi);pi.cancel();
   }
   JSONArray saved=new JSONArray();
   try{
    for(int i=0;i<Math.min(LIMIT,upcoming.size());i++){
     JSONObject e=upcoming.get(i);schedule(c,e.getLong("due"),intent(c,e.getString("id"),e.getString("date"),e.getLong("due")));saved.put(e);
    }
   }finally{c.getSharedPreferences("alarms",0).edit().putString("scheduled",saved.toString()).apply();}
   c.getSharedPreferences("status",0).edit().remove("alarm-error").apply();
   String next=saved.length()==0?"нет будущих":format(saved.getJSONObject(0).getLong("due"));
   ReminderLog.add(c,"Задач "+tasks.length()+", с напоминанием "+withReminders+". AlarmManager принял "+saved.length()+"; ближайшее "+next+"; точные="+exact(c));
  }catch(Exception e){
   c.getSharedPreferences("status",0).edit().putString("alarm-error","Ошибка планирования: "+e.getClass().getSimpleName()+". Откройте диагностику.").apply();ReminderLog.error(c,"Планирование",e);
  }
 }
 static void show(Context c,String id,String date,long expected){
  ReminderLog.add(c,"Receiver получил напоминание; назначено "+format(expected));
  try{
   JSONObject data=GitHubSync.local(c);
   if(done(c,data,id,date)){ReminderLog.add(c,"Пропуск: задача уже выполнена");return;}
   JSONObject task=null;JSONArray tasks=data.getJSONArray("tasks");for(int i=0;i<tasks.length();i++)if(id.equals(tasks.getJSONObject(i).getString("id")))task=tasks.getJSONObject(i);
   if(task==null||task.isNull("reminder")||!occurs(task,LocalDate.parse(date))){ReminderLog.add(c,"Пропуск: задача удалена или напоминание выключено");return;}
   if(ReminderRules.due(date,task.getString("time"),task.getInt("reminder"))!=expected){ReminderLog.add(c,"Пропуск: время задачи изменено");return;}
   NotificationManager manager=c.getSystemService(NotificationManager.class);channel(c);
   if(!allowed(c)){ReminderLog.add(c,"Уведомление заблокировано: проверьте разрешение и канал");return;}
   Intent done=new Intent(c,DoneReceiver.class).setAction("ru.pulse.DONE").setData(Uri.parse("pulse://done/"+Uri.encode(id)+"/"+date)).putExtra("id",id).putExtra("date",date);
   PendingIntent action=PendingIntent.getBroadcast(c,0,done,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
   Notification n=builder(c,task.getString("title"),task.getString("time")+" · Свои дела").addAction(new Notification.Action.Builder(null,"Выполнено",action).build()).build();
   manager.notify(tag(id,date),1,n);ReminderLog.add(c,"NotificationManager принял уведомление задачи");
  }catch(Exception e){ReminderLog.error(c,"Показ уведомления",e);}
 }
 private static boolean allowed(Context c){
  NotificationManager m=c.getSystemService(NotificationManager.class);NotificationChannel channel=m.getNotificationChannel("tasks");return m.areNotificationsEnabled()&&(channel==null||channel.getImportance()!=NotificationManager.IMPORTANCE_NONE);
 }
 private static Notification.Builder builder(Context c,String title,String text){
  PendingIntent open=PendingIntent.getActivity(c,0,new Intent(c,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  return new Notification.Builder(c,"tasks").setSmallIcon(R.drawable.icon).setContentTitle(title).setContentText(text).setContentIntent(open).setCategory(Notification.CATEGORY_REMINDER).setAutoCancel(true);
 }
 static void showTest(Context c){
  try{channel(c);if(!allowed(c)){ReminderLog.add(c,"Тест: уведомления запрещены системой или каналом");return;}
   c.getSystemService(NotificationManager.class).notify("pulse-diagnostic",2,builder(c,"Пульс · проверка уведомлений","Локальное уведомление. Интернет не используется.").build());ReminderLog.add(c,"NotificationManager принял тестовое уведомление");
  }catch(Exception e){ReminderLog.error(c,"Тест уведомления",e);}
 }
 static String testAlarm(Context c){
  try{long due=System.currentTimeMillis()+60000;Intent i=new Intent(c,ReminderReceiver.class).setAction("ru.pulse.TEST").setData(Uri.parse("pulse://diagnostic/alarm")).putExtra("due",due);
   PendingIntent pi=PendingIntent.getBroadcast(c,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);schedule(c,due,pi);
   String text="Тестовый будильник принят на "+format(due)+" МСК"+(exact(c)?"":" (приблизительно)");ReminderLog.add(c,text);return text;
  }catch(Exception e){ReminderLog.error(c,"Тест будильника",e);return "Android не принял будильник. Откройте диагностику.";}
 }
 private static String format(long time){return DateTimeFormatter.ofPattern("dd.MM HH:mm:ss").withZone(ZONE).format(Instant.ofEpochMilli(time));}
 static String diagnostics(Context c){
  channel(c);NotificationManager m=c.getSystemService(NotificationManager.class);PowerManager power=c.getSystemService(PowerManager.class);NotificationChannel channel=m.getNotificationChannel("tasks");
  StringBuilder text=new StringBuilder("Пульс 0.3.0-github\n").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append(" · Android ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
  text.append("Сейчас МСК: ").append(format(System.currentTimeMillis())).append("\nТочные будильники: ").append(exact(c)).append("\nУведомления приложения: ").append(m.areNotificationsEnabled()).append("\nВажность канала: ").append(channel==null?"нет":channel.getImportance()).append("\nЭнергосбережение: ").append(power.isPowerSaveMode()).append("\nБез оптимизации батареи: ").append(power.isIgnoringBatteryOptimizations(c.getPackageName()));
  long sync=c.getSharedPreferences("github-status",0).getLong("syncedAt",0);text.append("\nСинхронизация: ").append(sync==0?"не было":format(sync));text.append("\n").append(c.getSharedPreferences("status",0).getString("alarm-error",""));
  text.append("\n\nПоследние события (только на телефоне):\n").append(ReminderLog.read(c));return text.toString();
 }
}
