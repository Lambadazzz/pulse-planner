package ru.pulse.omnitest;
import android.content.*;
public final class ReminderReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){Reminders.show(c,i.getStringExtra("id"),i.getStringExtra("date"),i.getLongExtra("due",-1));Reminders.rebuild(c);}
}
