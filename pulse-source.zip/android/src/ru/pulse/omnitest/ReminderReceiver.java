package ru.pulse.omnitest;
import android.content.*;
public final class ReminderReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){if("ru.pulse.TEST".equals(i.getAction())){ReminderLog.add(c,"Receiver получил тестовый будильник");Reminders.showTest(c);return;}Reminders.show(c,i.getStringExtra("id"),i.getStringExtra("date"),i.getLongExtra("due",-1));Reminders.rebuild(c);}
}
