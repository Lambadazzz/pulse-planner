package ru.pulse.omnitest;
import android.Manifest;
import android.app.*;
import android.app.job.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.widget.*;
import org.json.*;
import java.time.LocalDate;
public final class ToolsActivity extends Activity {
 private android.view.View themeRoot;private boolean night;private TextView status;private CheckBox periodic;private final Handler handler=new Handler();
 private final Runnable refresh=new Runnable(){public void run(){if(themeRoot!=null&&night!=AppTheme.dark()){night=AppTheme.dark();AppTheme.prepare(ToolsActivity.this);AppTheme.paint(ToolsActivity.this,themeRoot);AppTheme.tintTree(themeRoot);}showStatus();handler.postDelayed(this,2000);}};
 @Override public void onCreate(Bundle state){AppTheme.prepare(this);super.onCreate(state);night=AppTheme.dark();ScrollView scroll=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(28,36,28,36);root.setBackgroundColor(AppTheme.background());scroll.addView(root);setContentView(scroll);themeRoot=scroll;AppTheme.paint(this,scroll);
  root.addView(text("пульс.\nНастройки Android и OMNI",25));root.addView(text("Данные зашифрованы в твоём приватном GitHub. Полученные задачи напомнят без интернета. Изменения с компьютера могут прийти с задержкой, пока приложение закрыто.",13));
  Reminders.channel(this);
  button(root,"Подключить GitHub",this::configure);button(root,"Обновить задачи сейчас",()->GitHubSync.sync(this,null,this::result));button(root,"Мои дела на сегодня",this::today);
  button(root,"Проверить уведомление сейчас",()->{Reminders.showTest(this);diagnostics();});
  button(root,"Проверить будильник через минуту",()->status(Reminders.testAlarm(this)));
  button(root,"Диагностика напоминаний",this::diagnostics);
  button(root,"Настройки уведомлений Android",()->startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName())));
  button(root,"Разрешить точные напоминания",()->{if(Build.VERSION.SDK_INT>=31&&!Reminders.exact(this))startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName())));else toast("Точные напоминания разрешены");});
  button(root,"Войти в OMNI",()->open(false));button(root,"Данные OMNI для автоматического входа",this::omniCredentials);button(root,"Обновить Академию и Колледж",()->omni(0));button(root,"Проверить OMNI после сворачивания (30 с)",()->omni(30000));button(root,"Вернуться в Пульс",()->finish());
  periodic=new CheckBox(this);periodic.setText("Автообновление: дела ~15 мин, OMNI ~час");periodic.setChecked(((JobScheduler)getSystemService(JOB_SCHEDULER_SERVICE)).getPendingJob(718775)!=null);if(!GitHubSync.configured(this)){getSystemService(JobScheduler.class).cancel(718775);periodic.setChecked(false);}periodic.setEnabled(GitHubSync.configured(this));periodic.setOnCheckedChangeListener((b,checked)->{getSharedPreferences("settings",0).edit().putBoolean("background-enabled",checked).apply();JobScheduler jobs=getSystemService(JobScheduler.class);if(checked){int accepted=jobs.schedule(new JobInfo.Builder(718775,new ComponentName(this,SyncJob.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPeriodic(15*60*1000L).setPersisted(true).build());if(accepted!=JobScheduler.RESULT_SUCCESS){periodic.setChecked(false);toast("Android не принял задание");}}else jobs.cancel(718775);});root.addView(periodic);
  root.addView(text("Android может отложить фоновую синхронизацию. Напоминание сработает только для уже полученной задачи. После принудительной остановки откройте помощник снова.",12));
  status=text("",14);status.setPadding(12,20,12,20);root.addView(status);
  if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},17);
 }
 private TextView text(String value,int size){TextView v=new TextView(this);v.setText(value);v.setTextSize(Math.max(16,size));v.setTextColor(AppTheme.foreground());v.setPadding(0,10,0,14);return v;}
 private void button(LinearLayout root,String title,Runnable action){Button b=new Button(this);b.setText(title);b.setAllCaps(false);b.setTextSize(16);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,6,0,6);root.addView(b,p);b.setOnClickListener(v->action.run());}
 private EditText field(LinearLayout form,String hint,boolean secret){EditText e=new EditText(this);e.setHint(hint);e.setSingleLine();if(secret)e.setInputType(129);form.addView(e);return e;}
 private void configure(){LinearLayout form=new LinearLayout(this);form.setOrientation(1);form.setPadding(32,8,32,8);EditText owner=field(form,"GitHub login",false),repo=field(form,"pulse-planner-data",false),token=field(form,"Fine-grained токен",true),phrase=field(form,"Фраза шифрования (не пароль GitHub)",true);repo.setText("pulse-planner-data");try{String c=new Vault(this).read("github-config");if(!c.isEmpty()){JSONObject old=new JSONObject(c);owner.setText(old.optString("owner"));repo.setText(old.optString("repo"));}}catch(Exception ignored){}new AlertDialog.Builder(this).setTitle("GitHub напрямую").setMessage("Тот же приватный репозиторий и фраза, что в браузере. Токен: Contents Read and write только для репозитория данных. Данные подключения защищены Android Keystore.").setView(form).setPositiveButton("Подключить",(d,w)->{try{JSONObject c=new JSONObject().put("owner",owner.getText().toString().trim()).put("repo",repo.getText().toString().trim()).put("token",token.getText().toString().trim()).put("phrase",phrase.getText().toString());status("Проверяем приватный репозиторий…");GitHubSync.configure(this,c,(ok,message)->{result(ok,message);periodic.setEnabled(GitHubSync.configured(this));});token.setText("");phrase.setText("");}catch(Exception e){toast("Проверьте подключение");}}).setNegativeButton("Отмена",null).show();}
 private void omniCredentials(){LinearLayout form=new LinearLayout(this);form.setOrientation(1);form.setPadding(32,8,32,8);EditText login=field(form,"Логин OMNI",false),pass=field(form,"Пароль OMNI",true);new AlertDialog.Builder(this).setTitle("Автоматический вход OMNI").setMessage("Данные шифруются на телефоне, в GitHub не передаются.").setView(form).setPositiveButton("Сохранить",(d,w)->{try{if(login.getText().toString().trim().isEmpty()||pass.length()==0){toast("Введите логин и пароль");return;}new Vault(this).save("credentials",new JSONObject().put("username",login.getText().toString().trim()).put("password",pass.getText().toString()).toString());pass.setText("");toast("Сохранено на телефоне");}catch(Exception e){toast("Не удалось сохранить данные");}}).setNeutralButton("Удалить сохранённые",(d,w)->new Vault(this).clearCredentials()).setNegativeButton("Отмена",null).show();}
 private void open(boolean browser){if(!browser&&OmniEngine.isRunning()){toast("Дождитесь завершения чтения OMNI");return;}if(browser)startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://lambadazzz.github.io/pulse-planner/")));else startActivity(new Intent(this,BrowserActivity.class));}
 private void omni(int delay){if(OmniEngine.loginBrowserOpen||OmniEngine.isRunning()){toast("Дождитесь завершения текущей проверки или закройте окно OMNI");return;}startForegroundService(new Intent(this,SyncService.class).putExtra("delay",delay));status(delay>0?"Через 30 секунд начнётся чтение OMNI. Нажмите «Домой».":"Читаем оба расписания…");}
 private void today(){
  try{
   JSONObject data=GitHubSync.local(this);JSONArray tasks=data.getJSONArray("tasks"),items=new JSONArray();LocalDate day=LocalDate.now(Reminders.ZONE);
   for(int i=0;i<tasks.length();i++){JSONObject task=tasks.getJSONObject(i);if(Reminders.occurs(task,day))items.put(task);}
   String[] labels=new String[items.length()];
   for(int i=0;i<items.length();i++){JSONObject task=items.getJSONObject(i);labels[i]=(Reminders.done(this,data,task.getString("id"),day.toString())?"✓ ":"")+task.getString("time")+" · "+task.getString("title");}
   new AlertDialog.Builder(this).setTitle("Сегодня · нажмите для подробностей").setItems(labels,(dialog,index)->{
    try{JSONObject task=items.getJSONObject(index);taskDetails(task,day.toString(),Reminders.done(this,data,task.getString("id"),day.toString()));}catch(Exception e){toast("Не удалось открыть задачу");}
   }).setPositiveButton("Закрыть",null).show();
  }catch(Exception e){toast("Сначала получите задачи из GitHub");}
 }
 private void taskDetails(JSONObject task,String date,boolean completed)throws Exception{
  String reminder=task.isNull("reminder")?"выключено":task.getInt("reminder")==0?"в начале":"за "+task.getInt("reminder")+" мин";
  String description=date+" · "+task.getString("time")+" МСК\nНапоминание: "+reminder+"\n"+(completed?"Выполнено":"Не выполнено")+"\n\n"+task.optString("notes","");
  AlertDialog.Builder dialog=new AlertDialog.Builder(this).setTitle(task.getString("title")).setMessage(description);
  if(completed)dialog.setPositiveButton("Закрыть",null);
  else dialog.setNegativeButton("Закрыть",null).setPositiveButton("Выполнено",(d,w)->{
   try{GitHubSync.markDone(this,task.getString("id"),date);ReminderLog.add(this,"Выполнено: явная кнопка в карточке задачи");Reminders.rebuild(this);GitHubSync.sync(this,null,this::result);}catch(Exception e){toast("Не удалось сохранить отметку");ReminderLog.error(this,"Выполнение из карточки",e);}
  });
  dialog.show();
 }
 private void status(String message){getSharedPreferences("status",0).edit().putString("message",message).apply();showStatus();}
 private void result(boolean ok,String message){status(message);}
 private void diagnostics(){TextView value=text(Reminders.diagnostics(this),13);value.setTextIsSelectable(true);value.setPadding(24,8,24,8);ScrollView scroll=new ScrollView(this);scroll.addView(value);new AlertDialog.Builder(this).setTitle("Диагностика напоминаний").setView(scroll).setPositiveButton("Закрыть",null).setNeutralButton("Скопировать",(d,w)->{getSystemService(android.content.ClipboardManager.class).setPrimaryClip(ClipData.newPlainText("Пульс · диагностика",value.getText()));toast("Диагностика скопирована. Токенов и паролей в ней нет.");}).show();}
 private void showStatus(){if(status==null)return;String message=getSharedPreferences("status",0).getString("message","Сначала подключите приватное GitHub-хранилище.");String alarmError=getSharedPreferences("status",0).getString("alarm-error","");status.setText(message+"\n\n"+(Reminders.exact(this)?"Точное время напоминаний разрешено.":"Точное время не разрешено: Android может задерживать уведомления.")+ (alarmError.isEmpty()?"":"\n"+alarmError));}
 private void toast(String message){Toast.makeText(this,message,Toast.LENGTH_LONG).show();}
 @Override protected void onResume(){super.onResume();getSharedPreferences("status",0).edit().putBoolean("visible",true).apply();handler.post(refresh);Reminders.rebuild(this);if(GitHubSync.configured(this)){long last=getSharedPreferences("github-status",0).getLong("foregroundAttempt",0);if(System.currentTimeMillis()-last>10000){getSharedPreferences("github-status",0).edit().putLong("foregroundAttempt",System.currentTimeMillis()).apply();GitHubSync.sync(this,null,this::result);}if(periodic!=null&&periodic.isChecked()&&System.currentTimeMillis()-getSharedPreferences("github-status",0).getLong("omniAttempt",0)>3600000&&!OmniEngine.loginBrowserOpen&&!OmniEngine.isRunning())omni(0);}}
 @Override protected void onPause(){super.onPause();getSharedPreferences("status",0).edit().putBoolean("visible",false).apply();handler.removeCallbacks(refresh);}
}
