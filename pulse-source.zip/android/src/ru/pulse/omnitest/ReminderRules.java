package ru.pulse.omnitest;
import java.time.*;
import java.util.*;
import java.util.function.Predicate;

final class ReminderRules {
 static final ZoneId ZONE=ZoneId.of("Europe/Moscow");
 static final class Entry {
  final LocalDate date; final long due;
  Entry(LocalDate date,long due){this.date=date;this.due=due;}
 }
 static boolean occurs(String startText,String repeat,LocalDate date){
  LocalDate start=LocalDate.parse(startText);
  if(date.isBefore(start))return false;
  switch(repeat){
   case "none":return date.equals(start);
   case "daily":return true;
   case "weekdays":return date.getDayOfWeek().getValue()<6;
   case "weekly":return date.getDayOfWeek()==start.getDayOfWeek();
   case "monthly":return date.getDayOfMonth()==Math.min(start.getDayOfMonth(),date.lengthOfMonth());
   default:throw new IllegalArgumentException("Unknown repeat");
  }
 }
 static long due(String date,String time,int reminder){return LocalDateTime.of(LocalDate.parse(date),LocalTime.parse(time)).atZone(ZONE).toInstant().toEpochMilli()-reminder*60000L;}
 static List<Entry> upcoming(String startText,String time,String repeat,int reminder,long now,Predicate<LocalDate> completed){
  LocalDate today=Instant.ofEpochMilli(now).atZone(ZONE).toLocalDate(),first=LocalDate.parse(startText);
  if(first.isBefore(today))first=today;
  List<Entry> result=new ArrayList<>();
  for(int j=0;j<14;j++){
   LocalDate day=first.plusDays(j);
   if(!occurs(startText,repeat,day)||completed.test(day))continue;
   long timestamp=due(day.toString(),time,reminder);
   if(timestamp>now)result.add(new Entry(day,timestamp));
  }
  return result;
 }
}
