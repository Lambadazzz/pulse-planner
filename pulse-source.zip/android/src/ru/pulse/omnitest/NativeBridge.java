package ru.pulse.omnitest;
import android.webkit.JavascriptInterface;
import android.content.*;
import org.json.*;
import java.util.*;
import java.util.concurrent.*;

final class NativeBridge {
 private final MainActivity activity;
 private final ExecutorService worker=Executors.newSingleThreadExecutor();
 NativeBridge(MainActivity activity){this.activity=activity;}
 @JavascriptInterface public void request(String raw){
  if(raw==null||raw.length()>1000000)return;
  worker.execute(()->{
   String id="";
   try{
    JSONObject call=new JSONObject(raw);id=call.getString("id");if(!id.matches("[A-Za-z0-9-]{1,60}"))return;
    String method=call.getString("method");JSONObject body=call.optJSONObject("body");if(body==null)body=new JSONObject();final String requestId=id;
    if(method.equals("configure")){
     GitHubSync.configure(activity,body,(ok,message)->{if(ok)activity.afterConfigure();try{if(ok)reply(requestId,bootstrap());else error(requestId,message);}catch(Exception e){error(requestId,"Не удалось открыть подключение.");}});return;
    }
    Object result;
    switch(method){
     case "bootstrap":result=bootstrap();break;
     case "state":result=state(activity);activity.poll();break;
     case "api":result=api(body);break;
     case "sync":activity.pollNow();result=new JSONObject().put("ok",true);break;
     case "tools":activity.runOnUiThread(()->activity.startActivity(new Intent(activity,ToolsActivity.class)));result=new JSONObject().put("ok",true);break;
     case "conflicts":activity.runOnUiThread(()->ConflictUi.show(activity));result=new JSONObject().put("ok",true);break;
     case "close":activity.runOnUiThread(activity::finish);result=new JSONObject().put("ok",true);break;
     default:throw new Exception("Неизвестное действие приложения.");
    }
    reply(id,result);
   }catch(Exception e){error(id,e instanceof java.io.IOException?"Не удалось сохранить на телефоне. Проверьте свободное место.":e.getMessage()==null?"Действие не выполнено.":e.getMessage());}
  });
 }
 private JSONObject bootstrap()throws Exception{
  String raw=new Vault(activity).read("github-config");JSONObject c=raw.isEmpty()?new JSONObject():new JSONObject(raw);
  return new JSONObject().put("configured",!raw.isEmpty()).put("owner",c.optString("owner")).put("repo",c.optString("repo","pulse-planner-data"));
 }
 static JSONObject state(Context c)throws Exception{
  JSONObject local=LocalPlanner.snapshot(c),data=PlannerEngine.view(local),mobile=data.optJSONObject("mobile");JSONArray lessons=new JSONArray();
  if(mobile!=null){JSONArray branches=mobile.getJSONArray("branches");for(int i=0;i<branches.length();i++){JSONArray list=branches.getJSONObject(i).getJSONArray("lessons");for(int j=0;j<list.length();j++)lessons.put(list.getJSONObject(j));}}
  JSONObject nativeState=new JSONObject().put("pending",local.getJSONArray("ops").length()).put("conflicts",local.getJSONArray("conflicts").length()).put("message",c.getSharedPreferences("github-status",0).getString("message","")).put("syncedAt",c.getSharedPreferences("github-status",0).getLong("syncedAt",0));
  return new JSONObject().put("tasks",data.getJSONArray("tasks")).put("completions",data.getJSONArray("completions")).put("lessons",lessons).put("omni",new JSONObject().put("connected",mobile!=null).put("mode","mobile").put("syncedAt",mobile==null?JSONObject.NULL:mobile.getString("capturedAt"))).put("native",nativeState).put("schedulerAt",JSONObject.NULL).put("pushKey",JSONObject.NULL);
 }
 private Object api(JSONObject request)throws Exception{
  if(!GitHubSync.configured(activity))throw new Exception("Сначала подключите GitHub.");
  String path=request.getString("path"),method=request.getString("method");JSONObject body=request.getJSONObject("body"),change=new JSONObject();String taskId=null;
  if(path.equals("/api/tasks")){
   if(method.equals("POST")){taskId=UUID.randomUUID().toString();body=PlannerEngine.copy(body).put("id",taskId).put("revision",1);change.put("kind","create").put("task",body);}
   else if(method.equals("PATCH")){taskId=body.getString("id");change.put("kind","update").put("task",body);}
   else if(method.equals("DELETE"))change.put("kind","delete").put("id",body.getString("id")).put("revision",body.getInt("revision"));
   else throw new Exception("Неизвестное изменение.");
  }else if(path.equals("/api/complete"))change.put("kind","complete").put("taskId",body.getString("taskId")).put("date",body.getString("date")).put("done",body.getBoolean("done"));
  else throw new Exception("Неизвестное действие.");
  JSONObject saved=LocalPlanner.enqueue(activity,change);Reminders.rebuild(activity);GitHubSync.kick(activity);
  return taskId==null?new JSONObject().put("ok",true):PlannerEngine.find(saved,taskId);
 }
 private void reply(String id,Object result){try{activity.reply(id,new JSONObject().put("ok",true).put("value",result));}catch(Exception e){error(id,"Ошибка ответа приложения.");}}
 private void error(String id,String message){try{activity.reply(id,new JSONObject().put("ok",false).put("error",message));}catch(Exception ignored){}}
 void close(){worker.shutdownNow();}
}
