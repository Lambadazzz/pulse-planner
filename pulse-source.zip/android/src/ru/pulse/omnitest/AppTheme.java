package ru.pulse.omnitest;
import android.app.Activity;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Build;
import android.view.*;
import android.webkit.WebView;
import android.widget.*;
import java.time.*;

final class AppTheme {
 static boolean dark(){return dark(System.currentTimeMillis());}
 static boolean dark(long time){int hour=Instant.ofEpochMilli(time).atZone(ZoneId.of("Europe/Moscow")).getHour();return hour>=20||hour<6;}
 static int background(){return dark()?Color.rgb(24,25,31):Color.rgb(246,246,248);}
 static int foreground(){return dark()?Color.rgb(241,237,246):Color.rgb(41,38,48);}
 static int muted(){return dark()?Color.rgb(188,180,201):Color.rgb(112,105,120);}
 static void prepare(Activity activity){activity.setTheme(dark()?android.R.style.Theme_Material_NoActionBar:android.R.style.Theme_Material_Light_NoActionBar);}
 static void paint(Activity activity,View root){
  int color=background();root.setBackgroundColor(color);activity.getWindow().setStatusBarColor(color);activity.getWindow().setNavigationBarColor(color);
  if(Build.VERSION.SDK_INT>=29){activity.getWindow().setStatusBarContrastEnforced(false);activity.getWindow().setNavigationBarContrastEnforced(false);}
  if(Build.VERSION.SDK_INT>=30){WindowInsetsController controller=activity.getWindow().getInsetsController();if(controller!=null){int mask=WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS|WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;controller.setSystemBarsAppearance(dark()?0:mask,mask);}}
  else{View decor=activity.getWindow().getDecorView();int mask=View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;decor.setSystemUiVisibility((decor.getSystemUiVisibility()&~mask)|(dark()?0:mask));}
 }
 static void tintTree(View view){
  if(view instanceof WebView)return;
  if(view.getBackground() instanceof android.graphics.drawable.ColorDrawable){int old=((android.graphics.drawable.ColorDrawable)view.getBackground()).getColor();if(old==Color.rgb(246,246,248)||old==Color.rgb(24,25,31))view.setBackgroundColor(background());}
  if(view instanceof TextView)((TextView)view).setTextColor(foreground());
  if(view instanceof EditText){((EditText)view).setHintTextColor(muted());view.setBackgroundTintList(ColorStateList.valueOf(dark()?Color.rgb(203,177,243):Color.rgb(113,85,160)));}
  if(view instanceof Button&&!(view instanceof CompoundButton))view.setBackgroundTintList(ColorStateList.valueOf(dark()?Color.rgb(48,43,64):Color.rgb(233,228,244)));
  if(view instanceof ViewGroup){ViewGroup group=(ViewGroup)view;for(int i=0;i<group.getChildCount();i++)tintTree(group.getChildAt(i));}
 }
}
