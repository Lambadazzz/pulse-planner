package ru.pulse.omnitest;
import android.content.*;
import android.app.NotificationManager;
import android.app.job.*;
public final class DoneReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){try{String id=i.getStringExtra("id"),date=i.getStringExtra("date");if(id==null||date==null)return;GitHubSync.markDone(c,id,date);ReminderLog.add(c,"Кнопка «Выполнено»: отметка сохранена локально");c.getSystemService(NotificationManager.class).cancel(Reminders.tag(id,date),1);Reminders.rebuild(c);c.getSystemService(JobScheduler.class).schedule(new JobInfo.Builder(718776,new ComponentName(c,SyncJob.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setMinimumLatency(1000).build());c.getSharedPreferences("status",0).edit().putString("message","Выполнение сохранено на телефоне и ожидает передачи в GitHub.").apply();}catch(Exception e){ReminderLog.error(c,"Кнопка «Выполнено»",e);}}
}
