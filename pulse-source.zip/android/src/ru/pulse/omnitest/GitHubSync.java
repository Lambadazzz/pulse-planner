package ru.pulse.omnitest;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import org.json.*;
import java.net.*;
import java.io.*;
import java.time.Instant;
import java.util.concurrent.*;
final class GitHubSync {
 interface Callback{void complete(boolean ok,String message);}
 private static final ExecutorService EXEC=Executors.newSingleThreadExecutor();
 private static final Handler MAIN=new Handler(Looper.getMainLooper());
 static boolean configured(Context c){try{return !new Vault(c).read("github-config").isEmpty();}catch(Exception e){return false;}}
 static void configure(Context context,JSONObject config,Callback callback){EXEC.execute(()->{try{
  validateConfig(config);JSONObject local=LocalPlanner.snapshot(context);boolean queued=local.getJSONArray("ops").length()>0||local.optJSONObject("mobilePending")!=null;String oldRaw=new Vault(context).read("github-config");JSONObject old=oldRaw.isEmpty()?new JSONObject():new JSONObject(oldRaw);boolean sameRepo=config.getString("owner").equalsIgnoreCase(old.optString("owner"))&&config.getString("repo").equalsIgnoreCase(old.optString("repo"));
  if(queued&&!sameRepo)throw new Exception("Сначала отправьте локальные правки прежнего подключения.");
  Response metadata=request(config,"","GET",null);if(metadata.status!=200||!new JSONObject(metadata.text).optBoolean("private"))throw new Exception("Нужен доступ к приватному репозиторию данных.");
  Record record=read(config,true);if(record.sha==null){if(!write(config,record.data,null))record=read(config,false);}
  if(!queued)LocalPlanner.initial(context,record.data);new Vault(context).save("github-config",config.toString());context.getSharedPreferences("github-status",0).edit().putLong("syncedAt",System.currentTimeMillis()).putString("message","GitHub подключён").apply();
  Reminders.rebuild(context);result(callback,true,"GitHub подключён. Данные доступны на телефоне.");
 }catch(Exception e){result(callback,false,message(e));}});}
 static void sync(Context context,JSONObject snapshot,Callback callback){EXEC.execute(()->{try{
  if(snapshot!=null)LocalPlanner.snapshot(context,snapshot);
  String raw=new Vault(context).read("github-config");if(raw.isEmpty())throw new Exception("Сначала настройте GitHub.");JSONObject config=new JSONObject(raw);validateConfig(config);
  JSONObject local=LocalPlanner.snapshot(context);JSONArray ops=local.getJSONArray("ops");JSONObject upload=local.optJSONObject("mobilePending");
  for(int attempt=0;attempt<4;attempt++){
   Record record=read(config,false);JSONObject merged=PlannerEngine.merge(record.data,ops),data=merged.getJSONObject("data");boolean changed=merged.getJSONArray("ack").length()>0;
   if(upload!=null){JSONObject old=data.optJSONObject("mobile");if(old==null||Instant.parse(upload.getString("capturedAt")).compareTo(Instant.parse(old.getString("capturedAt")))>0){data.put("mobile",upload);changed=true;}}
   if(!changed||write(config,data,record.sha)){
    LocalPlanner.accept(context,data,merged.getJSONArray("ack"),merged.getJSONArray("conflicts"));int conflicts=merged.getJSONArray("conflicts").length();String text=conflicts>0?"Есть конфликт правок. Выберите версию в настройках.":"GitHub обновлён";
    context.getSharedPreferences("github-status",0).edit().putLong("syncedAt",System.currentTimeMillis()).putString("message",text).apply();Reminders.rebuild(context);result(callback,conflicts==0,text);return;
   }
  }
  throw new Exception("Одновременная запись с другого устройства. Повторите синхронизацию.");
 }catch(Exception e){String text=message(e);context.getSharedPreferences("github-status",0).edit().putString("message",text).apply();Reminders.rebuild(context);result(callback,false,text);}});}
 private static final java.util.concurrent.atomic.AtomicBoolean KICKED=new java.util.concurrent.atomic.AtomicBoolean();
 static void kick(Context c){kick(c,()->{});}
 static void kick(Context c,Runnable finished){if(configured(c)&&KICKED.compareAndSet(false,true))sync(c,null,(ok,text)->{KICKED.set(false);finished.run();});}
 static JSONObject local(Context context)throws Exception{return LocalPlanner.view(context);}
 private static JSONObject empty()throws Exception{return new JSONObject().put("version",1).put("tasks",new JSONArray()).put("completions",new JSONArray()).put("mobile",JSONObject.NULL);}
 private static void validateConfig(JSONObject c)throws Exception{if(!c.optString("owner").matches("[A-Za-z0-9][A-Za-z0-9-]{0,38}")||!c.optString("repo").matches("[A-Za-z0-9_.-]{1,100}")||c.optString("token").isEmpty()||c.getString("token").matches(".*\\s.*")||c.optString("phrase").length()<12)throw new Exception("Проверьте GitHub, репозиторий, токен и фразу шифрования.");}
 private static final class Response{int status;String text;Response(int s,String t){status=s;text=t;}}
 private static final class Record{JSONObject data;String sha;Record(JSONObject d,String s){data=d;sha=s;}}
 private static Response request(JSONObject c,String path,String method,JSONObject body)throws Exception{URL url=new URL("https://api.github.com/repos/"+c.getString("owner")+"/"+c.getString("repo")+path);HttpsURLConnectionAdapter a=new HttpsURLConnectionAdapter(url);java.net.HttpURLConnection connection=a.connection;try{connection.setRequestMethod(method);connection.setConnectTimeout(15000);connection.setReadTimeout(20000);connection.setInstanceFollowRedirects(false);connection.setRequestProperty("Authorization","Bearer "+c.getString("token"));connection.setRequestProperty("Accept","application/vnd.github+json");connection.setRequestProperty("X-GitHub-Api-Version","2022-11-28");connection.setRequestProperty("User-Agent","Pulse-Android");if(body!=null){connection.setDoOutput(true);connection.setRequestProperty("Content-Type","application/json");byte[] bytes=body.toString().getBytes("UTF-8");connection.setFixedLengthStreamingMode(bytes.length);try(OutputStream out=connection.getOutputStream()){out.write(bytes);}}int status=connection.getResponseCode();if(status==401)throw new Exception("Токен GitHub не принят. Обновите подключение.");if(status==403)throw new Exception("GitHub запретил запрос: проверьте права токена и лимит API.");InputStream in=status>=400?connection.getErrorStream():connection.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream();if(in!=null){byte[] buffer=new byte[8192];for(int n;(n=in.read(buffer))!=-1;){if(out.size()+n>2500000)throw new Exception("Файл GitHub слишком большой.");out.write(buffer,0,n);}in.close();}return new Response(status,new String(out.toByteArray(),"UTF-8"));}finally{connection.disconnect();}}
 private static final class HttpsURLConnectionAdapter{java.net.HttpURLConnection connection;HttpsURLConnectionAdapter(URL url)throws Exception{connection=(javax.net.ssl.HttpsURLConnection)url.openConnection();}}
 private static Record read(JSONObject config,boolean create)throws Exception{Response r=request(config,"/contents/pulse-vault.json","GET",null);if(r.status==404&&create)return new Record(empty(),null);if(r.status!=200)throw new Exception("Не удалось прочитать файл GitHub ("+r.status+").");JSONObject file=new JSONObject(r.text);JSONObject e=new JSONObject(new String(CryptoCore.bytes(file.getString("content").replaceAll("\\s","")),"UTF-8"));if(e.optInt("version")!=1||e.optInt("iterations")!=CryptoCore.ROUNDS||!"PBKDF2-SHA256".equals(e.optString("kdf")))throw new Exception("Неизвестный формат шифрования.");JSONObject data;try{data=new JSONObject(new String(CryptoCore.decrypt(CryptoCore.bytes(e.getString("ciphertext")),config.getString("phrase"),CryptoCore.bytes(e.getString("salt")),CryptoCore.bytes(e.getString("iv"))),"UTF-8"));}catch(Exception ex){throw new Exception("Не удалось расшифровать данные. Проверьте фразу; файл не изменён.");}if(data.optInt("version")!=1||data.optJSONArray("tasks")==null||data.optJSONArray("completions")==null)throw new Exception("Повреждённый формат данных. Запись отменена.");return new Record(data,file.getString("sha"));}
 private static boolean write(JSONObject config,JSONObject data,String sha)throws Exception{byte[] salt=CryptoCore.random(16),iv=CryptoCore.random(12);JSONObject envelope=new JSONObject().put("version",1).put("kdf","PBKDF2-SHA256").put("iterations",CryptoCore.ROUNDS).put("salt",CryptoCore.b64(salt)).put("iv",CryptoCore.b64(iv)).put("ciphertext",CryptoCore.b64(CryptoCore.encrypt(data.toString().getBytes("UTF-8"),config.getString("phrase"),salt,iv)));byte[] bytes=envelope.toString().getBytes("UTF-8");if(bytes.length>900000)throw new Exception("Хранилище слишком большое. Сделайте экспорт.");JSONObject body=new JSONObject().put("message","Sync encrypted planner data").put("content",CryptoCore.b64(bytes));if(sha!=null)body.put("sha",sha);Response r=request(config,"/contents/pulse-vault.json","PUT",body);if(r.status==409||r.status==422)return false;if(r.status!=200&&r.status!=201)throw new Exception("GitHub не сохранил данные ("+r.status+").");return true;}
 static JSONArray pending(Context context){return new JSONArray();} // Legacy queue is migrated into LocalPlanner.
 static void markDone(Context context,String taskId,String date)throws Exception{LocalPlanner.enqueue(context,new JSONObject().put("kind","complete").put("taskId",taskId).put("date",date).put("done",true));}
 private static String message(Exception e){if(e instanceof java.io.IOException)return "Нет связи с GitHub. Полученные задачи и отметки сохранены на телефоне.";String value=e.getMessage();return value==null?"Не удалось синхронизировать GitHub.":value;}
 private static void result(Callback callback,boolean ok,String text){MAIN.post(()->callback.complete(ok,text));}
}
