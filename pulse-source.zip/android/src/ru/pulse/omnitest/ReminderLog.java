package ru.pulse.omnitest;
import android.content.Context;
import java.time.*;
import java.time.format.DateTimeFormatter;

final class ReminderLog {
 static synchronized void add(Context c,String message){
  String line=DateTimeFormatter.ofPattern("dd.MM HH:mm:ss").withZone(ReminderRules.ZONE).format(Instant.now())+" "+message;
  String old=c.getSharedPreferences("reminder-diagnostics",0).getString("log","");
  String[] lines=(line+"\n"+old).split("\n");StringBuilder limited=new StringBuilder();
  for(int i=0;i<Math.min(40,lines.length);i++)limited.append(lines[i]).append('\n');
  c.getSharedPreferences("reminder-diagnostics",0).edit().putString("log",limited.toString()).apply();
 }
 static void error(Context c,String stage,Exception e){
  String detail=String.valueOf(e.getMessage()).replace('\n',' ');if(detail.length()>180)detail=detail.substring(0,180);
  add(c,stage+": "+e.getClass().getSimpleName()+" "+detail);
 }
 static String read(Context c){return c.getSharedPreferences("reminder-diagnostics",0).getString("log","Пока нет событий.");}
}
