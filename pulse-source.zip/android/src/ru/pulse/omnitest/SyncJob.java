package ru.pulse.omnitest;
import android.app.job.*;
import java.util.HashSet;
public final class SyncJob extends JobService {
 private final HashSet<Integer> active=new HashSet<>();private OmniEngine engine;
 @Override public boolean onStartJob(JobParameters p){active.add(p.getJobId());GitHubSync.sync(this,null,(ok,message)->{if(!active.contains(p.getJobId()))return;status(message);long last=getSharedPreferences("github-status",0).getLong("omniAttempt",0);if(p.getJobId()==718775&&System.currentTimeMillis()-last>=3600000&&!OmniEngine.loginBrowserOpen&&!OmniEngine.isRunning()){getSharedPreferences("github-status",0).edit().putLong("omniAttempt",System.currentTimeMillis()).apply();engine=new OmniEngine(this,(snapshot,error)->{if(!active.contains(p.getJobId()))return;if(snapshot==null){status(error);finish(p,false);return;}try{new Vault(this).save("snapshot",snapshot.toString());GitHubSync.sync(this,snapshot,(saved,text)->{if(active.contains(p.getJobId())){status(text);finish(p,!saved);}});}catch(Exception e){status("Не удалось сохранить расписание на телефоне.");finish(p,false);}});engine.start();}else finish(p,!ok);});return true;}
 private void finish(JobParameters p,boolean retry){active.remove(p.getJobId());jobFinished(p,retry);}
 @Override public boolean onStopJob(JobParameters p){active.remove(p.getJobId());if(p.getJobId()==718775&&engine!=null)engine.cancel();return true;}
 private void status(String message){getSharedPreferences("status",0).edit().putString("message",message).apply();}
}
