package ru.pulse.omnitest;
import android.app.*;
import org.json.*;
final class ConflictUi {
 static void show(Activity a){try{
  JSONObject state=LocalPlanner.snapshot(a),local=PlannerEngine.view(state);JSONArray conflicts=state.getJSONArray("conflicts");
  if(conflicts.length()==0){new AlertDialog.Builder(a).setMessage("Конфликтов правок нет.").setPositiveButton("Закрыть",null).show();return;}
  String[] labels=new String[conflicts.length()];for(int i=0;i<conflicts.length();i++){String id=conflicts.getJSONObject(i).getString("taskId");JSONObject t=PlannerEngine.find(local,id);labels[i]=t==null?"Удалённая на телефоне задача":t.getString("title");}
  new AlertDialog.Builder(a).setTitle("Выберите конфликт для сравнения").setItems(labels,(dialog,index)->{try{
   String id=conflicts.getJSONObject(index).getString("taskId");JSONObject current=LocalPlanner.snapshot(a);JSONObject desired=PlannerEngine.find(PlannerEngine.view(current),id),remote=PlannerEngine.find(current.getJSONObject("base"),id);
   new AlertDialog.Builder(a).setTitle("Какую версию сохранить?").setMessage("На телефоне:\n"+describe(desired)+"\n\nВ GitHub:\n"+describe(remote)+"\n\nПринятие GitHub отменит локальные правки этой задачи.").setPositiveButton("Оставить телефон",(d,w)->resolve(a,id,true)).setNegativeButton("Принять GitHub",(d,w)->resolve(a,id,false)).setNeutralButton("Позже",null).show();
  }catch(Exception e){failure(a);}}).setPositiveButton("Закрыть",null).show();
 }catch(Exception e){failure(a);}}
 private static String describe(JSONObject task)throws Exception{return task==null?"Задачи нет":task.getString("title")+"\n"+task.getString("date")+" · "+task.getString("time")+"\n"+task.getString("notes");}
 private static void resolve(Activity a,String id,boolean keep){try{LocalPlanner.resolve(a,id,keep);Reminders.rebuild(a);GitHubSync.kick(a);if(a instanceof MainActivity)((MainActivity)a).changed();}catch(Exception e){failure(a);}}
 private static void failure(Activity a){new AlertDialog.Builder(a).setMessage("Не удалось открыть конфликт. Локальные изменения сохранены.").setPositiveButton("Закрыть",null).show();}
}
