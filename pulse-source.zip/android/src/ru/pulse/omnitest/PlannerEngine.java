package ru.pulse.omnitest;
import org.json.*;
import java.time.*;
import java.util.*;

// No Android dependencies: the same mutation engine is exercised on the JVM.
final class PlannerEngine {
 static final class Conflict extends Exception {Conflict(String message){super(message);}}
 static JSONObject copy(JSONObject value)throws Exception{return new JSONObject(value.toString());}
 static JSONObject empty()throws Exception{return new JSONObject().put("version",1).put("tasks",new JSONArray()).put("completions",new JSONArray()).put("mobile",JSONObject.NULL);}
 static JSONObject task(JSONObject input)throws Exception{
  String id=input.getString("id"),title=input.getString("title"),notes=input.getString("notes"),date=input.getString("date"),time=input.getString("time"),repeat=input.getString("repeat");
  if(id.isEmpty()||id.length()>100||title.trim().isEmpty()||title.length()>180||notes.length()>5000)throw new Exception("Проверьте название и заметку задачи.");
  if(!date.matches("\\d{4}-\\d{2}-\\d{2}")||!LocalDate.parse(date).toString().equals(date)||!time.matches("([01]\\d|2[0-3]):[0-5]\\d"))throw new Exception("Проверьте дату и время.");
  if(!Arrays.asList("none","daily","weekdays","weekly","monthly").contains(repeat))throw new Exception("Проверьте повторение.");
  int duration=integer(input,"duration"),revision=integer(input,"revision");
  if(duration<5||duration>1440||revision<1||revision==Integer.MAX_VALUE)throw new Exception("Проверьте длительность и версию задачи.");
  Object reminder=JSONObject.NULL;if(!input.has("reminder"))throw new Exception("Проверьте напоминание.");
  if(!input.isNull("reminder")){int value=integer(input,"reminder");if(!Arrays.asList(0,5,10,15,30,60,120,1440).contains(value))throw new Exception("Проверьте напоминание.");reminder=value;}
  return new JSONObject().put("id",id).put("title",title.trim()).put("notes",notes.trim()).put("date",date).put("time",time).put("repeat",repeat).put("duration",duration).put("revision",revision).put("reminder",reminder);
 }
 static int integer(JSONObject input,String key)throws Exception{Object value=input.get(key);if(!(value instanceof Number)||((Number)value).doubleValue()!=((Number)value).intValue())throw new Exception("Некорректное число: "+key);return ((Number)value).intValue();}
 static JSONObject validate(JSONObject input)throws Exception{
  if(input.getInt("version")!=1)throw new Exception("Неизвестный формат данных.");JSONObject d=copy(input);JSONArray tasks=d.getJSONArray("tasks"),completions=d.getJSONArray("completions");
  if(tasks.length()>5000||completions.length()>30000)throw new Exception("Слишком много записей.");Set<String> ids=new HashSet<>();
  for(int i=0;i<tasks.length();i++){JSONObject t=task(tasks.getJSONObject(i));if(!ids.add(t.getString("id")))throw new Exception("Повторяющаяся задача.");tasks.put(i,t);}
  for(int i=0;i<completions.length();i++){JSONObject c=completions.getJSONObject(i);c.getString("taskId");LocalDate.parse(c.getString("date"));}
  return d;
 }
 static JSONObject find(JSONObject data,String id)throws Exception{JSONArray tasks=data.getJSONArray("tasks");for(int i=0;i<tasks.length();i++)if(id.equals(tasks.getJSONObject(i).getString("id")))return tasks.getJSONObject(i);return null;}
 static String taskId(JSONObject op)throws Exception{return op.has("task")?op.getJSONObject("task").getString("id"):op.has("taskId")?op.getString("taskId"):op.getString("id");}
 static boolean equalTask(JSONObject a,JSONObject b)throws Exception{if(a==null||b==null)return a==b;for(String key:new String[]{"id","title","notes","date","time","repeat","duration","revision","reminder"})if(!String.valueOf(a.get(key)).equals(String.valueOf(b.get(key))))return false;return true;}
 private static void replace(JSONObject data,String id,JSONObject task)throws Exception{JSONArray old=data.getJSONArray("tasks"),next=new JSONArray();boolean added=false;for(int i=0;i<old.length();i++){JSONObject t=old.getJSONObject(i);if(id.equals(t.getString("id"))){if(task!=null){next.put(task);added=true;}}else next.put(t);}if(task!=null&&!added)next.put(task);data.put("tasks",next);}
 static JSONObject apply(JSONObject original,JSONObject op,boolean force)throws Exception{
  JSONObject data=copy(original);String kind=op.getString("kind"),id=taskId(op);JSONObject current=find(data,id);
  if(kind.equals("create")||kind.equals("update")){
   JSONObject desired=task(op.getJSONObject("task"));int expected=desired.getInt("revision");desired.put("revision",kind.equals("create")?1:expected+1);
   if(!force){
    if(equalTask(current,desired))return data; // A successful PUT may have lost its response.
    if(kind.equals("create")?current!=null:current==null||current.getInt("revision")!=expected)throw new Conflict("Задачу изменили на другом устройстве.");
   }
   replace(data,id,desired);
  }else if(kind.equals("delete")){
   if(!force&&current!=null&&current.getInt("revision")!=integer(op,"revision"))throw new Conflict("Удаляемую задачу изменили на другом устройстве.");
   replace(data,id,null);JSONArray next=new JSONArray(),old=data.getJSONArray("completions");for(int i=0;i<old.length();i++)if(!id.equals(old.getJSONObject(i).getString("taskId")))next.put(old.getJSONObject(i));data.put("completions",next);
  }else if(kind.equals("complete")){
   String date=op.getString("date");LocalDate day=LocalDate.parse(date);boolean done=op.getBoolean("done");
   if(!force&&(current==null||!ReminderRules.occurs(current.getString("date"),current.getString("repeat"),day)))throw new Conflict("Задача больше не существует в этом дне.");
   JSONArray next=new JSONArray(),old=data.getJSONArray("completions");for(int i=0;i<old.length();i++){JSONObject c=old.getJSONObject(i);if(!id.equals(c.getString("taskId"))||!date.equals(c.getString("date")))next.put(c);}if(done&&current!=null)next.put(new JSONObject().put("taskId",id).put("date",date));data.put("completions",next);
  }else throw new Exception("Неизвестное изменение задачи.");
  if(data.getJSONArray("tasks").length()>5000||data.getJSONArray("completions").length()>30000)throw new Exception("Слишком много записей.");return data;
 }
 static JSONObject view(JSONObject state)throws Exception{JSONObject data=copy(state.getJSONObject("base"));JSONArray ops=state.getJSONArray("ops");for(int i=0;i<ops.length();i++)data=apply(data,ops.getJSONObject(i),true);JSONObject pending=state.optJSONObject("mobilePending"),old=data.optJSONObject("mobile");if(pending!=null&&(old==null||Instant.parse(pending.getString("capturedAt")).isAfter(Instant.parse(old.getString("capturedAt")))))data.put("mobile",pending);return data;}
 static JSONObject merge(JSONObject remote,JSONArray ops)throws Exception{
  JSONObject data=validate(remote);JSONArray ack=new JSONArray(),conflicts=new JSONArray();Set<String> blocked=new HashSet<>();
  for(int i=0;i<ops.length();i++){
   JSONObject op=ops.getJSONObject(i);String id=taskId(op);if(blocked.contains(id))continue;
   try{data=apply(data,op,false);ack.put(op.getString("operationId"));}catch(Conflict e){blocked.add(id);conflicts.put(new JSONObject().put("operationId",op.getString("operationId")).put("taskId",id).put("message",e.getMessage()));}
  }
  return new JSONObject().put("data",data).put("ack",ack).put("conflicts",conflicts);
 }
 static JSONObject accept(JSONObject current,JSONObject remote,JSONArray ack,JSONArray conflicts)throws Exception{
  JSONObject next=copy(current);Set<String> removed=new HashSet<>();for(int i=0;i<ack.length();i++)removed.add(ack.getString(i));JSONArray kept=new JSONArray();Set<String> remaining=new HashSet<>();
  for(int i=0;i<current.getJSONArray("ops").length();i++){JSONObject op=current.getJSONArray("ops").getJSONObject(i);if(!removed.contains(op.getString("operationId"))){kept.put(op);remaining.add(op.getString("operationId"));}}
  JSONArray active=new JSONArray();for(int i=0;i<conflicts.length();i++)if(remaining.contains(conflicts.getJSONObject(i).getString("operationId")))active.put(conflicts.getJSONObject(i));
  JSONObject pending=next.optJSONObject("mobilePending"),mobile=remote.optJSONObject("mobile");if(pending!=null&&mobile!=null&&!Instant.parse(pending.getString("capturedAt")).isAfter(Instant.parse(mobile.getString("capturedAt"))))next.remove("mobilePending");return next.put("base",validate(remote)).put("ops",kept).put("conflicts",active);
 }
 static JSONObject operation(JSONObject change)throws Exception{return copy(change).put("operationId",UUID.randomUUID().toString());}
 static JSONObject resolve(JSONObject original,String id,boolean keepLocal)throws Exception{
  JSONObject state=copy(original),local=view(state),desired=find(local,id),remote=find(state.getJSONObject("base"),id);JSONArray ops=new JSONArray(),conflicts=new JSONArray();
  for(int i=0;i<state.getJSONArray("ops").length();i++){JSONObject op=state.getJSONArray("ops").getJSONObject(i);if(!id.equals(taskId(op)))ops.put(op);}
  for(int i=0;i<state.getJSONArray("conflicts").length();i++){JSONObject c=state.getJSONArray("conflicts").getJSONObject(i);if(!id.equals(c.getString("taskId")))conflicts.put(c);}
  if(keepLocal){
   if(desired==null&&remote!=null)ops.put(operation(new JSONObject().put("kind","delete").put("id",id).put("revision",remote.getInt("revision"))));
   else if(desired!=null){
    JSONObject t=copy(desired).put("revision",remote==null?1:remote.getInt("revision"));ops.put(operation(new JSONObject().put("kind",remote==null?"create":"update").put("task",t)));
    Set<String> dates=new HashSet<>(),done=new HashSet<>();for(JSONArray list:new JSONArray[]{local.getJSONArray("completions"),state.getJSONObject("base").getJSONArray("completions")})for(int i=0;i<list.length();i++){JSONObject c=list.getJSONObject(i);if(id.equals(c.getString("taskId")))dates.add(c.getString("date"));}
    JSONArray completions=local.getJSONArray("completions");for(int i=0;i<completions.length();i++){JSONObject c=completions.getJSONObject(i);if(id.equals(c.getString("taskId")))done.add(c.getString("date"));}
    for(String date:dates)if(ReminderRules.occurs(t.getString("date"),t.getString("repeat"),LocalDate.parse(date)))ops.put(operation(new JSONObject().put("kind","complete").put("taskId",id).put("date",date).put("done",done.contains(date))));
   }
  }
  return state.put("ops",ops).put("conflicts",conflicts);
 }
}
