package ru.pulse.omnitest;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;
public final class BrowserActivity extends Activity {
 private WebView web;
 @Override public void onCreate(Bundle state){AppTheme.prepare(this);super.onCreate(state);OmniEngine.loginBrowserOpen=true;LinearLayout root=new LinearLayout(this);root.setOrientation(1);TextView info=new TextView(this);info.setText("Войдите в OMNI, затем вернитесь в Пульс. Доступны оба филиала: «Ейск» и «Ейск Колледж».");info.setPadding(20,28,20,15);root.addView(info);Button back=new Button(this);back.setText("Вернуться в Пульс");back.setOnClickListener(v->finish());root.addView(back);web=OmniEngine.createWebView(this);web.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView view,String url){if(!"omni.top-academy.ru".equals(android.net.Uri.parse(url).getHost()))return;view.evaluateJavascript("sessionStorage.getItem('IdLocalHash')",raw->{try{Object hash=new org.json.JSONTokener(raw).nextValue();if(hash instanceof String&&!((String)hash).isEmpty())new Vault(BrowserActivity.this).save("omniHash",(String)hash);}catch(Exception ignored){}});}});root.addView(web,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);AppTheme.paint(this,root);AppTheme.tintTree(root);web.loadUrl(OmniEngine.ORIGIN+"/#/schedulePage");}
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
 @Override protected void onDestroy(){OmniEngine.loginBrowserOpen=false;if(web!=null){web.stopLoading();web.destroy();}super.onDestroy();}
}
