package ru.pulse.omnitest;
import android.Manifest;
import android.app.*;
import android.app.job.*;
import android.content.*;
import android.graphics.Color;
import android.net.*;
import android.os.*;
import android.webkit.*;
import java.io.*;
import java.util.*;
import org.json.*;

public final class MainActivity extends Activity {
 private static final String ORIGIN="https://appassets.androidplatform.net",START=ORIGIN+"/pulse/index.html";
 private WebView web;private NativeBridge bridge;private long pollAttempt;
 @Override public void onCreate(Bundle state){
  super.onCreate(state);getWindow().setStatusBarColor(Color.rgb(35,35,41));getWindow().setNavigationBarColor(Color.rgb(246,246,248));
  android.widget.FrameLayout root=new android.widget.FrameLayout(this);web=new WebView(this);root.addView(web,new android.widget.FrameLayout.LayoutParams(-1,-1));setContentView(root);
  getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
  if(Build.VERSION.SDK_INT>=30){getWindow().setDecorFitsSystemWindows(false);root.setOnApplyWindowInsetsListener((view,insets)->{android.graphics.Insets bars=insets.getInsets(android.view.WindowInsets.Type.systemBars()|android.view.WindowInsets.Type.displayCutout()),ime=insets.getInsets(android.view.WindowInsets.Type.ime());view.setPadding(bars.left,bars.top,bars.right,Math.max(bars.bottom,ime.bottom));return insets;});}
  WebSettings settings=web.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);settings.setAllowFileAccess(false);settings.setAllowContentAccess(false);settings.setAllowFileAccessFromFileURLs(false);settings.setAllowUniversalAccessFromFileURLs(false);settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);settings.setJavaScriptCanOpenWindowsAutomatically(false);settings.setSupportMultipleWindows(false);settings.setMediaPlaybackRequiresUserGesture(true);settings.setBlockNetworkLoads(false); // HTTPS asset interception runs after the global network-block check; CSP and the closed asset router prohibit external loads.
  CookieManager.getInstance().setAcceptThirdPartyCookies(web,false);bridge=new NativeBridge(this);web.addJavascriptInterface(bridge,"PulseNative");
  web.setWebChromeClient(new WebChromeClient());
  web.setWebViewClient(new WebViewClient(){
   @Override public void onReceivedError(WebView view,WebResourceRequest request,WebResourceError error){if(request.isForMainFrame())loadFailure("Не удалось открыть интерфейс. Код WebView: "+error.getErrorCode());}
   @Override public boolean onRenderProcessGone(WebView view,RenderProcessGoneDetail detail){view.destroy();web=null;loadFailure("WebView завершил работу. Локальные данные сохранены отдельно.");return true;}
   @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){return !page(request.getUrl());}
   @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request){
    Uri uri=request.getUrl();String path=uri.getPath();
    try{
     if(!request.getMethod().equals("GET")||!local(uri)||path==null||!path.startsWith("/pulse/")||path.contains(".."))return blocked();
     String file=path.substring("/pulse/".length());if(file.isEmpty())file="index.html";
     String mime=file.endsWith(".html")?"text/html":file.endsWith(".js")?"text/javascript":file.endsWith(".css")?"text/css":file.endsWith(".svg")?"image/svg+xml":file.endsWith(".png")?"image/png":"application/octet-stream";
     Map<String,String> headers=new HashMap<>();headers.put("Cache-Control","no-store");headers.put("X-Content-Type-Options","nosniff");headers.put("Content-Security-Policy","default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'none'; frame-src 'none'; worker-src 'none'; object-src 'none'; base-uri 'self'; form-action 'none'");
     return new WebResourceResponse(mime,"UTF-8",200,"OK",headers,getAssets().open("planner/"+file));
    }catch(Exception e){return blocked();}
   }
  });
  Reminders.channel(this);web.loadUrl(START);
  if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},17);
 }
 private static boolean local(Uri uri){return "https".equals(uri.getScheme())&&"appassets.androidplatform.net".equals(uri.getHost())&&uri.getPort()==-1;}
 private void loadFailure(String message){if(isFinishing())return;android.widget.LinearLayout root=new android.widget.LinearLayout(this);root.setOrientation(1);root.setPadding(32,64,32,32);android.widget.TextView text=new android.widget.TextView(this);text.setText(message);root.addView(text);android.widget.Button retry=new android.widget.Button(this);retry.setText("Открыть Пульс снова");retry.setOnClickListener(v->recreate());root.addView(retry);android.widget.Button tools=new android.widget.Button(this);tools.setText("Настройки и диагностика");tools.setOnClickListener(v->startActivity(new Intent(this,ToolsActivity.class)));root.addView(tools);setContentView(root);ReminderLog.add(this,message);}
 private static boolean page(Uri uri){return local(uri)&&("/pulse/".equals(uri.getPath())||"/pulse/index.html".equals(uri.getPath()));}
 private static WebResourceResponse blocked(){return new WebResourceResponse("text/plain","UTF-8",403,"Blocked",new HashMap<>(),new ByteArrayInputStream(new byte[0]));}
 void reply(String id,JSONObject result){runOnUiThread(()->{if(web!=null&&web.getUrl()!=null&&page(Uri.parse(web.getUrl())))web.evaluateJavascript("window.__pulseReply&&window.__pulseReply("+JSONObject.quote(id)+","+JSONObject.quote(result.toString())+")",null);});}
 void changed(){runOnUiThread(()->{if(web!=null&&web.getUrl()!=null&&page(Uri.parse(web.getUrl())))web.evaluateJavascript("window.dispatchEvent(new Event('pulse:native-changed'))",null);});}
 void poll(){if(System.currentTimeMillis()-pollAttempt>15000)pollNow();}
 void pollNow(){pollAttempt=System.currentTimeMillis();if(online()&&GitHubSync.configured(this))GitHubSync.kick(this,this::changed);}
 private boolean online(){ConnectivityManager manager=getSystemService(ConnectivityManager.class);Network network=manager.getActiveNetwork();NetworkCapabilities caps=network==null?null:manager.getNetworkCapabilities(network);return caps!=null&&caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);}
 void afterConfigure(){runOnUiThread(()->{enableBackground();changed();});}
 private void enableBackground(){
  if(!GitHubSync.configured(this)||!getSharedPreferences("settings",0).getBoolean("background-enabled",true))return;
  JobScheduler jobs=getSystemService(JobScheduler.class);if(jobs.getPendingJob(718775)==null)jobs.schedule(new JobInfo.Builder(718775,new ComponentName(this,SyncJob.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPeriodic(15*60*1000L).setPersisted(true).build());
 }
 @Override protected void onResume(){super.onResume();Reminders.rebuild(this);enableBackground();pollNow();changed();
  if(GitHubSync.configured(this)&&getSharedPreferences("settings",0).getBoolean("background-enabled",true)&&System.currentTimeMillis()-getSharedPreferences("github-status",0).getLong("omniAttempt",0)>3600000&&!OmniEngine.loginBrowserOpen&&!OmniEngine.isRunning())startForegroundService(new Intent(this,SyncService.class));
 }
 @Override public void onBackPressed(){if(web==null){super.onBackPressed();return;}web.evaluateJavascript("(()=>{const d=document.querySelector('dialog[open]');if(!d)return false;d.dispatchEvent(new Event('cancel',{cancelable:true}));return true;})()",value->{if(!"true".equals(value))finish();});}
 @Override protected void onDestroy(){if(bridge!=null)bridge.close();if(web!=null){web.removeJavascriptInterface("PulseNative");web.stopLoading();web.destroy();web=null;}super.onDestroy();}
}
