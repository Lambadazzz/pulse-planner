package ru.pulse.omnitest;
import android.content.*;
public final class BootReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){Reminders.rebuild(c);}
}
