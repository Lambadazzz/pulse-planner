package ru.pulse.omnitest;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.webkit.CookieManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.*;
import java.io.*;
import java.time.Instant;
import java.util.UUID;
final class OmniEngine {
 private static final java.util.concurrent.atomic.AtomicBoolean RUNNING=new java.util.concurrent.atomic.AtomicBoolean(false);
 static volatile boolean loginBrowserOpen=false;
 static boolean isRunning(){return RUNNING.get();}
 private boolean lockOwned=false;
 interface Callback{void complete(JSONObject snapshot,String error);}
 private final Context context;private final Callback callback;private final Handler handler=new Handler(Looper.getMainLooper());
 private WebView web;private String reader;private String hashSeed="";private boolean ended=false,evaluating=false,reading=false,sessionRecorded=false;private int branch=0;
 private long deadline,loginSent=0,switchStarted=0;private String switched="",navigated="",run="",originalCity="";private JSONArray results=new JSONArray();
 static final String ORIGIN="https://omni.top-academy.ru";
 OmniEngine(Context context,Callback callback){this.context=context.getApplicationContext();this.callback=callback;}
 static WebView createWebView(Context context){WebView w=new WebView(context);w.getSettings().setJavaScriptEnabled(true);w.getSettings().setDomStorageEnabled(true);w.getSettings().setAllowFileAccess(false);w.getSettings().setAllowContentAccess(false);w.getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW);CookieManager.getInstance().setAcceptCookie(true);CookieManager.getInstance().setAcceptThirdPartyCookies(w,false);return w;}
 void start(){if(loginBrowserOpen||!RUNNING.compareAndSet(false,true)){finish(null,"Закройте окно входа OMNI или дождитесь уже запущенной проверки.");return;}lockOwned=true;try{InputStream in=context.getAssets().open("omni-reader.js");ByteArrayOutputStream bytes=new ByteArrayOutputStream();byte[] buf=new byte[8192];for(int n;(n=in.read(buf))!=-1;)bytes.write(buf,0,n);in.close();reader=new String(bytes.toByteArray(),"UTF-8");web=createWebView(context);web.setWebViewClient(new WebViewClient());deadline=System.currentTimeMillis()+180000;web.loadUrl(ORIGIN+"/#/schedulePage");handler.postDelayed(this::step,900);}catch(Exception e){finish(null,"Не удалось запустить браузерный компонент Android.");}}
 private void again(){if(!ended)handler.postDelayed(this::step,700);}
 private void step(){if(ended)return;if(System.currentTimeMillis()>deadline){finish(null,"Время проверки истекло. Откройте вход OMNI и проверьте, нет ли запроса подтверждения.");return;}if(evaluating){again();return;}if(web.getUrl()==null||!"omni.top-academy.ru".equals(android.net.Uri.parse(web.getUrl()).getHost())){again();return;}evaluating=true;
  if(hashSeed.isEmpty()){try{String saved=new Vault(context).read("omniHash");if(!saved.isEmpty())hashSeed="if(!sessionStorage.getItem('IdLocalHash'))sessionStorage.setItem('IdLocalHash',"+JSONObject.quote(saved)+");";}catch(Exception ignored){}}
  String js=reading?"JSON.stringify(window.__pulseOmniResult||{})":hashSeed+reader+";(()=>{const s=PulseOmniReader.inspect();s.sessionHash=sessionStorage.getItem('IdLocalHash');return JSON.stringify(s)})()";
  web.evaluateJavascript(js,raw->{evaluating=false;if(ended)return;try{JSONObject value=decode(raw);if(reading){if(!run.equals(value.optString("run"))||!value.optBoolean("done")){again();return;}if(!value.optBoolean("ok")){finish(null,value.optString("message","Не удалось прочитать расписание."));return;}JSONObject item=new JSONObject().put("source",value.getString("source")).put("label",value.getString("label")).put("lessons",value.getJSONArray("lessons"));results.put(item);branch++;reading=false;switched="";navigated="";if(branch==2){JSONObject snapshot=new JSONObject().put("version",1).put("capturedAt",Instant.now().toString()).put("branches",results);CookieManager.getInstance().flush();if(!originalCity.isEmpty())web.loadUrl(ORIGIN+"/auth/change-city?city="+originalCity);handler.postDelayed(()->finish(snapshot,null),1500);return;}again();return;}
   if(value.optBoolean("login")){autoLogin();again();return;}
   String city=value.optString("city");if(city.isEmpty()){again();return;}if(!sessionRecorded){String activeHash=value.optString("sessionHash","");if(!activeHash.isEmpty()&&!"null".equals(activeHash)){new Vault(context).save("omniHash",activeHash);sessionRecorded=true;}}
   JSONArray cities=value.optJSONArray("branches");if(originalCity.isEmpty()&&cities!=null){for(int i=0;i<cities.length();i++){JSONObject c=cities.getJSONObject(i);if(city.equals(c.getString("label")))originalCity=c.getString("id");}}
   String desired=branch==0?"Ейск":"Ейск Колледж";
   if(!desired.equals(city)){if(!desired.equals(switched)){String id="";if(cities!=null)for(int i=0;i<cities.length();i++){JSONObject c=cities.getJSONObject(i);if(desired.equals(c.getString("label")))id=c.getString("id");}if(!id.matches("[0-9]+")){finish(null,"В OMNI не найден филиал «"+desired+"». Данные не заменены.");return;}switched=desired;switchStarted=System.currentTimeMillis();web.loadUrl(ORIGIN+"/auth/change-city?city="+id);}else if(System.currentTimeMillis()-switchStarted>25000){finish(null,"OMNI не подтвердил переключение на «"+desired+"».");return;}again();return;}
   if(!value.optBoolean("schedule")){if(!desired.equals(navigated)){navigated=desired;web.loadUrl(ORIGIN+"/#/schedulePage");}again();return;}
   run=UUID.randomUUID().toString();reading=true;web.evaluateJavascript(reader+";PulseOmniReader.capture("+JSONObject.quote(run)+","+JSONObject.quote(branch==0?"academy":"college")+");",null);again();
  }catch(Exception e){again();}});
 }
 private void autoLogin(){try{if(loginSent>0){if(System.currentTimeMillis()-loginSent>20000)finish(null,"Автоматический вход не завершился. Откройте OMNI: возможно, нужен код, CAPTCHA или исправление пароля.");return;}String stored=new Vault(context).read("credentials");if(stored.isEmpty()){finish(null,"Сессия OMNI закончилась. Войдите в OMNI или сохраните данные автоматического входа.");return;}JSONObject credentials=new JSONObject(stored);String js="(()=>{const u=document.querySelector('[ng-model=\"form.username\"]'),p=document.querySelector('[ng-model=\"form.password\"]');const b=Array.from(document.querySelectorAll('button')).find(b=>b.textContent.trim()==='Войти');if(!u||!p||!b)return false;u.value="+JSONObject.quote(credentials.getString("username"))+";u.dispatchEvent(new Event('input',{bubbles:true}));p.value="+JSONObject.quote(credentials.getString("password"))+";p.dispatchEvent(new Event('input',{bubbles:true}));b.click();return true;})()";web.evaluateJavascript(js,result->{if("true".equals(result))loginSent=System.currentTimeMillis();});}catch(Exception e){finish(null,"Не удалось открыть защищённые данные авто-входа. Сохраните их заново.");}}
 static JSONObject decode(String raw)throws Exception{Object value=new JSONTokener(raw==null?"null":raw).nextValue();if(value instanceof String)return new JSONObject((String)value);if(value instanceof JSONObject)return (JSONObject)value;return new JSONObject();}
 void cancel(){finish(null,"Проверка остановлена Android. Сохранённые данные не изменены.");}
 private void finish(JSONObject snapshot,String error){if(ended)return;ended=true;if(lockOwned){lockOwned=false;RUNNING.set(false);}handler.removeCallbacksAndMessages(null);if(web!=null){web.stopLoading();web.destroy();}callback.complete(snapshot,error);}
}
