package ru.pulse.omnitest;
import android.app.*;
import android.content.Intent;
import android.os.*;
public final class SyncService extends Service {
 private OmniEngine engine;private final Handler handler=new Handler(Looper.getMainLooper());private boolean running=false;private PowerManager.WakeLock wake;
 @Override public IBinder onBind(Intent i){return null;}
 @Override public int onStartCommand(Intent intent,int flags,int startId){if(running)return START_NOT_STICKY;running=true;wake=((PowerManager)getSystemService(POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"Pulse:OmniSync");wake.acquire(300000);NotificationManager manager=getSystemService(NotificationManager.class);manager.createNotificationChannel(new NotificationChannel("sync","Чтение расписания",NotificationManager.IMPORTANCE_LOW));PendingIntent open=PendingIntent.getActivity(this,1,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);startForeground(718,new Notification.Builder(this,"sync").setSmallIcon(R.drawable.icon).setContentTitle("Пульс читает OMNI").setContentText("Академия и Колледж · без окна сайта").setContentIntent(open).setOngoing(true).build());int delay=intent==null?0:Math.max(0,Math.min(30000,intent.getIntExtra("delay",0)));handler.postDelayed(this::run,delay);return START_NOT_STICKY;}
 private void run(){getSharedPreferences("github-status",0).edit().putLong("omniAttempt",System.currentTimeMillis()).apply();engine=new OmniEngine(this,(snapshot,error)->{if(snapshot==null){status(error);stopSelf();return;}try{new Vault(this).save("snapshot",snapshot.toString());String summary="Прочитаны оба филиала. ";GitHubSync.sync(this,snapshot,(ok,message)->{status(summary+message);stopSelf();});}catch(Exception e){status("Не удалось сохранить расписание на телефоне.");stopSelf();}});engine.start();}
 private void status(String text){getSharedPreferences("status",0).edit().putString("message",text).apply();}
 @Override public void onDestroy(){handler.removeCallbacksAndMessages(null);if(engine!=null)engine.cancel();if(wake!=null&&wake.isHeld())wake.release();stopForeground(STOP_FOREGROUND_REMOVE);super.onDestroy();}
}
