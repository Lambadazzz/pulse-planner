import { parseSchedule } from '../../lib/omni';
type Branch='academy'|'college';
const labels={academy:'Ейск',college:'Ейск Колледж'};
const normalize=(text:string)=>text.replace(/\s+/g,' ').trim();
export function inspect(){
 const selector=document.querySelector('button[aria-label="Open sample menu"]');
 const city=selector?normalize(selector.textContent??''):'';
 const branches=Array.from(document.querySelectorAll('#cityes button[ng-click]')).map(b=>({label:normalize(b.textContent??''),id:b.getAttribute('ng-click')?.match(/changeCity\((\d+)\)/)?.[1]??''})).filter(b=>b.id);
 return {city,branches,login:location.pathname.includes('/login'),schedule:location.hash.includes('/schedulePage')&&!!document.querySelector('table'),title:document.title};
}
export function capture(run:string,source:Branch){
 const target=window as Window & {__pulseOmniResult?:unknown};
 target.__pulseOmniResult={run,done:false};
 void(async()=>{try{
  if(location.origin!=='https://omni.top-academy.ru'||inspect().city!==labels[source])throw Error('Филиал не подтверждён. Загрузка отменена.');
  const csrf=document.querySelector('meta[name="csrf-token"]')?.getAttribute('content');
  if(!csrf)throw Error('Войдите в OMNI в приложении.');
  const lessons=[];
  for(const week of [-1,0,1,2,3,4]){
   if(inspect().city!==labels[source])throw Error('Филиал изменился во время загрузки. Повторите проверку.');
   const r=await fetch('/schedule/get-schedule',{method:'POST',credentials:'same-origin',redirect:'error',headers:{'Content-Type':'application/json','X-Requested-With':'XMLHttpRequest','X-CSRF-Token':csrf,'Id-Local-Hash':sessionStorage.getItem('IdLocalHash')??''},body:JSON.stringify({week}),signal:AbortSignal.timeout(15000)});
   if(!r.ok||!r.headers.get('content-type')?.includes('json'))throw Error('OMNI завершил сессию или не отдал расписание. Войдите повторно.');
   lessons.push(...parseSchedule(await r.json(),week).map(l=>({...l,id:source+':'+l.id,source})));
  }
  target.__pulseOmniResult={run,done:true,ok:true,source,label:labels[source],lessons:[...new Map(lessons.map(l=>[l.id,l])).values()]};
 }catch(e){target.__pulseOmniResult={run,done:true,ok:false,message:(e as Error).message};}})();
}
