import type { Lesson, LessonSource } from './planner';
export type MobileSnapshot = { version:1; capturedAt:string; branches:{source:LessonSource;label:string;lessons:Lesson[]}[] };
export function validateSnapshot(value:unknown,now=Date.now()):MobileSnapshot {
 const s=value as MobileSnapshot;
 if(!s||s.version!==1||typeof s.capturedAt!=='string'||!Number.isFinite(Date.parse(s.capturedAt))||Date.parse(s.capturedAt)>now+300000||now-Date.parse(s.capturedAt)>7*86400000)throw new Error('Нужен снимок расписания не старше семи дней.');
 if(!Array.isArray(s.branches)||s.branches.length!==2||s.branches.some(b=>!b||typeof b!=='object')||new Set(s.branches.map(b=>b.source)).size!==2)throw new Error('Нужны оба расписания: Академия и Колледж.');
 const branches=s.branches.map(b=>{
  if(!['academy','college'].includes(b.source)||b.label!==(b.source==='academy'?'Ейск':'Ейск Колледж')||!Array.isArray(b.lessons)||b.lessons.length>2000)throw new Error('Не удалось подтвердить филиал расписания.');
  const lessons=b.lessons.map(l=>{
   if(!l||typeof l.id!=='string'||!l.id.startsWith(b.source+':')||l.id.length>600||l.source!==b.source)throw new Error('Источник занятия не совпадает с филиалом.');
   if(typeof l.date!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(l.date)||!Number.isFinite(Date.parse(l.date))||new Date(l.date+'T00:00:00Z').toISOString().slice(0,10)!==l.date)throw new Error('Некорректная дата занятия.');
   if(!/^([01]\d|2[0-3]):[0-5]\d$/.test(l.start)||!/^([01]\d|2[0-3]):[0-5]\d$/.test(l.end)||l.end<=l.start)throw new Error('Некорректное время занятия.');
   if(typeof l.title!=='string'||!l.title.trim()||l.title.length>500||typeof l.group!=='string'||l.group.length>500||typeof l.room!=='string'||l.room.length>500)throw new Error('Не удалось прочитать описание занятия.');
   return {id:l.id,date:l.date,start:l.start,end:l.end,title:l.title.trim(),group:l.group,room:l.room,source:b.source};
  });
  if(new Set(lessons.map(l=>l.id)).size!==lessons.length)throw new Error('В расписании обнаружены повторяющиеся идентификаторы.');
  return {source:b.source,label:b.label,lessons};
 });
 return {version:1,capturedAt:new Date(s.capturedAt).toISOString(),branches};
}
