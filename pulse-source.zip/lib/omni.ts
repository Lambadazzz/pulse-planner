import type { Lesson } from './planner';
import { addDays, dateKey } from './planner';
const ORIGIN = 'https://omni.top-academy.ru';
export type OmniCredentials = { username: string; password: string };
export type OmniSession = { cookies: Record<string,string>; csrf: string; hash?: string };
function saveCookies(session: OmniSession, response: Response) {
  const values = response.headers.getSetCookie?.() ?? (response.headers.get('set-cookie')?.split(/,(?=\s*[^;,=]+=[^;,]*)/) ?? []);
  for (const value of values) { const pair = value.split(';')[0]; const at = pair.indexOf('='); if (at > 0) session.cookies[pair.slice(0,at).trim()] = pair.slice(at+1); }
}
async function request(path: string, session: OmniSession, data?: unknown) {
  const headers: Record<string,string> = { Cookie: Object.entries(session.cookies).map(([k,v])=>`${k}=${v}`).join('; '), 'User-Agent': 'Mozilla/5.0 PulsePlanner/1.0' };
  if (data !== undefined) Object.assign(headers, { 'Content-Type': 'application/json;charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest', 'X-CSRF-Token': session.csrf, Origin: ORIGIN, Referer: ORIGIN + '/' });
  if (session.hash) headers['Id-Local-Hash'] = session.hash;
  const response = await fetch(ORIGIN + path, { method: data === undefined ? 'GET' : 'POST', headers, body: data === undefined ? undefined : JSON.stringify(data), redirect: 'manual', signal: AbortSignal.timeout(15000) });
  saveCookies(session, response);
  return response;
}
export async function login(credentials: OmniCredentials): Promise<OmniSession> {
  const session: OmniSession = { cookies: {}, csrf: '' };
  const response = await request('/login/index', session);
  const html = await response.text();
  session.csrf = html.match(/<meta\s+name=["']csrf-token["']\s+content=["']([^"']+)/i)?.[1] ?? '';
  if (!response.ok || !session.csrf) {
    if (response.status===403 && /DDoS-Guard/i.test(html)) throw new Error('Защита OMNI отклонила подключение с сервера. Ваш логин и пароль ещё не проверялись.');
    throw new Error('OMNI не открыл форму входа. Попробуйте позже.');
  }
  const auth = await request('/auth/login', session, { LoginForm: { username: credentials.username, password: credentials.password } });
  if (!auth.headers.get('content-type')?.includes('json')) throw new Error('OMNI запросил дополнительную проверку входа.');
  const result = await auth.json() as { success?: boolean; IdLocalHash?: string };
  if (!auth.ok || result.success !== true) throw new Error('OMNI отклонил вход. Проверьте логин и пароль.');
  session.hash = result.IdLocalHash;
  const home = await request('/', session);
  const homeHtml = await home.text();
  session.csrf = homeHtml.match(/<meta\s+name=["']csrf-token["']\s+content=["']([^"']+)/i)?.[1] ?? session.csrf;
  return session;
}
type Item = Record<string, unknown>;
function first(item: Item, names: string[]) { for (const name of names) if (item[name] != null && typeof item[name] !== 'object') return String(item[name]); return ''; }
function clean(value: string) { return value.replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').trim(); }
export function parseSchedule(raw: unknown, week: number): Lesson[] {
  const r = raw as { body?: unknown; dates?: Record<string,string> };
  if (!r || !r.body || !r.dates) throw new Error('OMNI изменил формат расписания. Сохранённые пары не удалены.');
  const out: Lesson[] = [];
  const today = dateKey(); const weekday = new Date(today+'T12:00:00Z').getUTCDay() || 7;
  const monday = addDays(today, 1-weekday + week*7);
  const dates: Record<string,string> = {};
  for (const [key, text] of Object.entries(r.dates)) {
    if (/^\d{4}-\d{2}-\d{2}/.test(String(text))) { dates[key]=String(text).slice(0,10); continue; }
    const match = String(text).match(/(\d{1,2})[.\/-](\d{1,2})(?:[.\/-](\d{2,4}))?/);
    if (match) { const ref=addDays(monday,Math.max(0,Number(key)-1)); let year=match[3] ? (match[3].length===2?'20'+match[3]:match[3]) : ref.slice(0,4); dates[key]=`${year}-${match[2].padStart(2,'0')}-${match[1].padStart(2,'0')}`; }
  }
  const walk = (node: unknown, path: string[]) => {
    if (!node || typeof node !== 'object') return;
    const item = node as Item;
    if (typeof item.l_start === 'string' && typeof item.l_end === 'string') {
      const ownDate = first(item,['date','lesson_date','date_lesson','date_start']);
      let day = /^\d{4}-\d{2}-\d{2}/.test(ownDate) ? ownDate.slice(0,10) : '';
      if (!day) { const key = path[1]; day=dates[key] ?? ''; }
      const title=clean(item.scheduleType==='event' ? `${first(item,['eventName'])} / ${first(item,['eventSubtypeName'])}` : first(item,['name_spec']));
      if (!day || !title) throw new Error('Не удалось распознать поля пары OMNI. Сохранённое расписание не изменено.');
      const start=String(item.l_start).slice(0,5),end=String(item.l_end).slice(0,5);
      const group=clean(first(item,['groups'])); const room=clean(first(item,['num_rooms']));
      out.push({id:`${day}-${start}-${first(item,['id','id_lesson']) || group+'-'+title}`,date:day,start,end,title,group,room}); return;
    }
    for (const [key,value] of Object.entries(item)) walk(value,[...path,key]);
  };
  walk(r.body,[]);
  return [...new Map(out.map(x=>[x.id,x])).values()];
}
export async function getSchedule(credentials: OmniCredentials, previous?: OmniSession): Promise<{ session: OmniSession; lessons: Lesson[] }> {
  let session = previous ?? await login(credentials);
  const lessons: Lesson[] = [];
  for (const week of [-1,0,1,2,3,4]) {
    let response=await request('/schedule/get-schedule',session,{week});
    if ([301,302,303,401,403,409].includes(response.status) || !response.headers.get('content-type')?.includes('json')) {
      session=await login(credentials); response=await request('/schedule/get-schedule',session,{week});
    }
    if (!response.ok || !response.headers.get('content-type')?.includes('json')) throw new Error('OMNI временно не отдаёт расписание. Сохранённые пары доступны.');
    lessons.push(...parseSchedule(await response.json(),week));
  }
  return { session, lessons };
}
