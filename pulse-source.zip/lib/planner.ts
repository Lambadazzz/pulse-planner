export type Repeat = 'none' | 'daily' | 'weekdays' | 'weekly' | 'monthly';
export type Task = { id: string; title: string; notes: string; date: string; time: string; duration: number; repeat: Repeat; reminder: number | null; revision: number };
export type LessonSource = 'academy' | 'college';
export type Lesson = { id: string; date: string; start: string; end: string; title: string; group: string; room: string; source?: LessonSource };
export type Completion = { taskId: string; date: string };
export const TIMEZONE = 'Europe/Moscow';
export function dateKey(value = new Date(), zone = TIMEZONE) {
  return new Intl.DateTimeFormat('en-CA', { timeZone: zone, year: 'numeric', month: '2-digit', day: '2-digit' }).format(value);
}
export function addDays(day: string, delta: number) { const d = new Date(day + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + delta); return d.toISOString().slice(0, 10); }
export function occurs(task: Pick<Task, 'date' | 'repeat'>, day: string) {
  if (day < task.date) return false;
  const delta = Math.round((Date.parse(day + 'T12:00:00Z') - Date.parse(task.date + 'T12:00:00Z')) / 86400000);
  if (task.repeat === 'none') return delta === 0;
  if (task.repeat === 'daily') return true;
  if (task.repeat === 'weekly') return delta % 7 === 0;
  if (task.repeat === 'weekdays') return ![0, 6].includes(new Date(day + 'T12:00:00Z').getUTCDay());
  const monthEnd = new Date(Date.UTC(Number(day.slice(0, 4)), Number(day.slice(5, 7)), 0)).getUTCDate();
  return Number(day.slice(8)) === Math.min(Number(task.date.slice(8)), monthEnd);
}
export function localInstant(day: string, time: string, zone = TIMEZONE) {
  const target = Date.parse(day + 'T' + time + ':00Z');
  let value = target;
  for (let i = 0; i < 3; i++) {
    const parts = new Intl.DateTimeFormat('sv-SE', { timeZone: zone, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' }).format(new Date(value));
    value += target - Date.parse(parts.replace(' ', 'T') + 'Z');
  }
  return value;
}
export function validateTask(input: unknown): Omit<Task, 'id' | 'revision'> {
  const t = input as Task;
  if (!t || typeof t.title !== 'string' || !t.title.trim() || t.title.length > 180) throw new Error('Введите название до 180 символов.');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(t.date) || !Number.isFinite(Date.parse(t.date)) || new Date(t.date + 'T00:00:00Z').toISOString().slice(0,10) !== t.date) throw new Error('Проверьте дату.');
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(t.time)) throw new Error('Проверьте время.');
  if (!['none','daily','weekdays','weekly','monthly'].includes(t.repeat)) throw new Error('Проверьте повторение.');
  if (!Number.isInteger(t.duration) || t.duration < 5 || t.duration > 1440) throw new Error('Длительность: от 5 минут до 24 часов.');
  if (t.reminder !== null && (![0,5,10,15,30,60,120,1440].includes(t.reminder))) throw new Error('Проверьте напоминание.');
  if (typeof t.notes !== 'string' || t.notes.length > 5000) throw new Error('Заметка — до 5000 символов.');
  return { title: t.title.trim(), notes: t.notes.trim(), date: t.date, time: t.time, duration: t.duration, repeat: t.repeat, reminder: t.reminder };
}
