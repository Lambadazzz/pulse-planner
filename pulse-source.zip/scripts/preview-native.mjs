import {build} from 'esbuild';
import {mkdir,writeFile,readFile,copyFile} from 'node:fs/promises';
import {createServer} from 'node:http';
const folder='.sites-runtime/native-preview';await mkdir(folder,{recursive:true});
await build({entryPoints:['github-app/tests/native-preview.ts'],bundle:true,format:'esm',target:'chrome100',jsx:'automatic',define:{'process.env.NODE_ENV':'"production"'},outfile:folder+'/fixture.js'});
await copyFile('github-app/public/theme.js',folder+'/theme.js');
await writeFile(folder+'/index.html','<!doctype html><html lang="ru"><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Пульс · UI fixture</title><script src="/theme.js"></script><link rel="stylesheet" href="/fixture.css"><div id="root"></div><script type="module" src="/fixture.js"></script></html>');
createServer(async(req,res)=>{const pathname=new URL(req.url,'http://localhost').pathname;const file=pathname==='/'?'index.html':pathname.slice(1);if(!/^[\w.-]+$/.test(file)){res.writeHead(403).end();return;}try{const body=await readFile(folder+'/'+file);res.writeHead(200,{'Content-Type':file.endsWith('.js')?'text/javascript':file.endsWith('.css')?'text/css':'text/html','Cache-Control':'no-store'}).end(body);}catch{res.writeHead(404).end();}}).listen(5175,'127.0.0.1',()=>console.log('Native UI fixture: http://127.0.0.1:5175'));
