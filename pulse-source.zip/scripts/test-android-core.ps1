$ErrorActionPreference='Stop'
$projectRoot=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
Push-Location $projectRoot
try {
 New-Item -ItemType Directory -Force -Path .sites-runtime\android-core-tests | Out-Null
 $jsonJar=Join-Path $projectRoot '.sites-runtime\json-20250517.jar'
 if(!(Test-Path -LiteralPath $jsonJar)){Invoke-WebRequest -Uri 'https://repo.maven.apache.org/maven2/org/json/json/20250517/json-20250517.jar' -OutFile $jsonJar}
 if((Get-FileHash -LiteralPath $jsonJar -Algorithm SHA256).Hash -ne '3EA61B2A06E31EDF1C91134FE9106B0EBB16628BE169F3DB75BC7A2B06B45796'){throw 'org.json checksum mismatch'}
 javac -encoding UTF-8 -classpath $jsonJar -d .sites-runtime\android-core-tests android\src\ru\pulse\omnitest\ReminderRules.java android\src\ru\pulse\omnitest\PlannerEngine.java tests\PlannerEngineTest.java tests\ReminderRulesTest.java
 if($LASTEXITCODE -ne 0){throw 'Java compilation failed'}
 java -cp ".sites-runtime\android-core-tests;$jsonJar" ru.pulse.omnitest.PlannerEngineTest
 if($LASTEXITCODE -ne 0){throw 'Offline engine tests failed'}
 java -cp .sites-runtime\android-core-tests ru.pulse.omnitest.ReminderRulesTest
 if($LASTEXITCODE -ne 0){throw 'Reminder rules tests failed'}
} finally {Pop-Location}
