$ErrorActionPreference='Stop'
$sdkRoot=Join-Path ([IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))) '.sites-runtime\android-sdk'
New-Item -ItemType Directory -Force -Path $sdkRoot | Out-Null
# Official SDK archive names and SHA-1 checksums from Google's repository2-1.xml.
$items=@(
 @{Name='platform-35-ext15_r01.zip';Sha1='ce757091f933b7ac646bf197ce8957cc73b95614'},
 @{Name='build-tools_r35_windows.zip';Sha1='af059bb67cf7786f45ee0db85e2d24985df1b4b6'},
 @{Name='platform-tools_r37.0.1-win.zip';Sha1='e03e78b1d80b396f1c3358e31251cb31740e1110'}
)
foreach($item in $items){$file=Join-Path $sdkRoot $item.Name;if(!(Test-Path -LiteralPath $file)){Invoke-WebRequest -Uri ('https://dl.google.com/android/repository/'+$item.Name) -OutFile $file};if((Get-FileHash -LiteralPath $file -Algorithm SHA1).Hash.ToLowerInvariant() -ne $item.Sha1){throw ('Checksum mismatch: '+$item.Name)};Expand-Archive -LiteralPath $file -DestinationPath $sdkRoot -Force;Write-Output ('SDK ready: '+$item.Name)}
