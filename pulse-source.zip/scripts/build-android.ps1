param([string]$SdkRoot = '')
$ErrorActionPreference='Stop'
$projectRoot=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
if(!$SdkRoot){$SdkRoot=Join-Path $projectRoot '.sites-runtime\android-sdk'}
$tools=Join-Path $SdkRoot 'android-15'
$androidJar=Join-Path $SdkRoot 'android-35-ext15\android.jar'
$javaProperties=(& java '-XshowSettings:properties' '-version' 2>&1 | Out-String)
$jdkRoot=([regex]::Match($javaProperties,'java\.home\s*=\s*([^\r\n]+)')).Groups[1].Value.Trim()
if(!$jdkRoot){throw 'Unable to resolve JDK tools.'}
$jarTool=Join-Path $jdkRoot 'bin\jar.exe'
$keyTool=Join-Path $jdkRoot 'bin\keytool.exe'
if(!(Test-Path -LiteralPath $androidJar)){throw 'Android SDK missing. Run scripts/setup-android.ps1 first.'}
$buildRoot=Join-Path $projectRoot ('android\build\'+[DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss'))
foreach($folder in @('classes','gen','dex')){New-Item -ItemType Directory -Force -Path (Join-Path $buildRoot $folder)|Out-Null}
function Checked([scriptblock]$action){& $action;if($LASTEXITCODE -ne 0){throw "Build tool failed ($LASTEXITCODE)"}}
Push-Location $projectRoot
try {
 Checked {node node_modules\esbuild\bin\esbuild android\bridge\reader.ts --bundle --format=iife --global-name=PulseOmniReader --target=chrome100 --outfile=android\assets\omni-reader.js}
 Checked {& "$tools\aapt2.exe" compile --dir android\res -o "$buildRoot\resources.zip"}
 Checked {& "$tools\aapt2.exe" link -o "$buildRoot\base.apk" --manifest android\AndroidManifest.xml -I $androidJar -R "$buildRoot\resources.zip" -A android\assets --java "$buildRoot\gen" --min-sdk-version 26 --target-sdk-version 35 --auto-add-overlay}
 $javaSources=@(Get-ChildItem -LiteralPath android\src -Filter '*.java' -Recurse | ForEach-Object FullName)+@(Get-ChildItem -LiteralPath "$buildRoot\gen" -Filter '*.java' -Recurse|ForEach-Object FullName)
 Checked {javac -encoding UTF-8 --release 8 -classpath $androidJar -d "$buildRoot\classes" @javaSources}
 Checked {& $jarTool --create --file "$buildRoot\classes.jar" -C "$buildRoot\classes" .}
 Checked {java -cp "$tools\lib\d8.jar" com.android.tools.r8.D8 --min-api 26 --lib $androidJar --output "$buildRoot\dex" "$buildRoot\classes.jar"}
 Checked {& $jarTool --update --file "$buildRoot\base.apk" -C "$buildRoot\dex" classes.dex}
 Checked {& "$tools\zipalign.exe" -f -p 4 "$buildRoot\base.apk" "$buildRoot\aligned.apk"}
 $key=Join-Path $projectRoot '.sites-runtime\android-test-signing.p12'
 if(!(Test-Path -LiteralPath $key)){Checked {& $keyTool -genkeypair -keystore $key -storepass android -keypass android -alias pulse-test -keyalg RSA -keysize 2048 -validity 3650 -dname 'CN=Pulse Test, O=Local Development, C=RU' -noprompt}}
 New-Item -ItemType Directory -Force -Path outputs | Out-Null
 $apk=Join-Path $projectRoot 'outputs\pulse-omni-test.apk'
 Checked {java -jar "$tools\lib\apksigner.jar" sign --ks $key --ks-key-alias pulse-test --ks-pass pass:android --key-pass pass:android --out $apk "$buildRoot\aligned.apk"}
 Checked {java -jar "$tools\lib\apksigner.jar" verify --verbose $apk}
 Checked {& "$tools\aapt2.exe" dump badging $apk}
 if(Test-Path -LiteralPath (Join-Path $projectRoot 'public')){Copy-Item -LiteralPath $apk -Destination (Join-Path $projectRoot 'public\pulse-omni-test.apk') -Force}
 Copy-Item -LiteralPath $apk -Destination (Join-Path $projectRoot 'github-app\public\pulse-android.apk') -Force
 Get-FileHash -LiteralPath $apk -Algorithm SHA256 | Select-Object Path,Hash
} finally {Pop-Location}
