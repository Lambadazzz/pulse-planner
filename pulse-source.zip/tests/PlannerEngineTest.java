package ru.pulse.omnitest;
import org.json.*;
public class PlannerEngineTest {
 static int checks;
 static void check(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
 static JSONObject task(String id,String title)throws Exception{return new JSONObject().put("id",id).put("title",title).put("notes","").put("date","2026-11-02").put("time","18:56").put("repeat","daily").put("duration",30).put("reminder",0).put("revision",1);}
 static JSONObject op(String kind,JSONObject task)throws Exception{return PlannerEngine.operation(new JSONObject().put("kind",kind).put("task",task));}
 static JSONObject state(JSONObject base,JSONArray ops)throws Exception{return new JSONObject().put("base",base).put("ops",ops).put("conflicts",new JSONArray());}
 static void reject(JSONObject base,JSONObject op)throws Exception{try{PlannerEngine.apply(base,op,false);throw new AssertionError("expected conflict");}catch(PlannerEngine.Conflict expected){checks++;}}
 public static void main(String[] args)throws Exception{
  JSONObject base=PlannerEngine.empty(),created=task("phone","На телефоне"),create=op("create",created);
  JSONObject edit=op("update",PlannerEngine.copy(created).put("title","Правка офлайн"));
  JSONObject complete=PlannerEngine.operation(new JSONObject().put("kind","complete").put("taskId","phone").put("date","2026-11-02").put("done",true));
  JSONArray queue=new JSONArray().put(create).put(edit).put(complete);
  JSONObject saved=state(base,queue),restarted=new JSONObject(saved.toString()),view=PlannerEngine.view(restarted);
  check(PlannerEngine.find(view,"phone").getString("title").equals("Правка офлайн"),"offline edit survives serialization/restart");
  check(PlannerEngine.find(view,"phone").getInt("revision")==2,"local revisions advance");
  check(view.getJSONArray("completions").length()==1,"offline completion visible");
  JSONObject remote=PlannerEngine.apply(base,op("create",task("pc","На компьютере")),false);
  JSONObject merge=PlannerEngine.merge(remote,queue);
  check(merge.getJSONObject("data").getJSONArray("tasks").length()==2,"independent PC change preserved");
  check(merge.getJSONArray("ack").length()==3&&merge.getJSONArray("conflicts").length()==0,"offline chain acknowledged");
  JSONObject accepted=PlannerEngine.accept(restarted,merge.getJSONObject("data"),merge.getJSONArray("ack"),merge.getJSONArray("conflicts"));
  check(accepted.getJSONArray("ops").length()==0,"acknowledged queue drained");
  JSONObject newer=op("update",PlannerEngine.copy(PlannerEngine.find(view,"phone")).put("notes","Создано пока сеть отвечала"));
  JSONObject concurrent=state(base,new JSONArray(queue.toString()).put(newer));
  JSONObject kept=PlannerEngine.accept(concurrent,merge.getJSONObject("data"),merge.getJSONArray("ack"),merge.getJSONArray("conflicts"));
  check(kept.getJSONArray("ops").length()==1,"new local mutation during network write is not removed");
  check(PlannerEngine.find(PlannerEngine.view(kept),"phone").getString("notes").contains("сеть"),"new mutation remains visible");
  JSONObject old=PlannerEngine.apply(base,create,false),pcEdit=PlannerEngine.apply(old,op("update",PlannerEngine.copy(created).put("title","Изменено на компьютере")),false);
  JSONObject conflict=PlannerEngine.merge(pcEdit,new JSONArray().put(edit).put(complete));
  check(conflict.getJSONArray("conflicts").length()==1,"stale edit produces conflict");
  check(conflict.getJSONArray("ack").length()==0,"dependent completion stays queued");
  JSONObject pending=state(old,new JSONArray().put(edit).put(complete));pending=PlannerEngine.accept(pending,conflict.getJSONObject("data"),conflict.getJSONArray("ack"),conflict.getJSONArray("conflicts"));
  check(PlannerEngine.find(PlannerEngine.view(pending),"phone").getString("title").equals("Правка офлайн"),"conflicting local version retained");
  JSONObject localChoice=PlannerEngine.resolve(pending,"phone",true),resolved=PlannerEngine.merge(pcEdit,localChoice.getJSONArray("ops"));
  check(resolved.getJSONArray("conflicts").length()==0,"explicit local choice rebases safely");
  check(PlannerEngine.find(resolved.getJSONObject("data"),"phone").getInt("revision")==3,"resolution increments current remote revision");
  check(resolved.getJSONObject("data").getJSONArray("completions").length()==1,"local completion retained on resolution");
  JSONObject remoteChoice=PlannerEngine.resolve(pending,"phone",false);
  check(remoteChoice.getJSONArray("ops").length()==0&&PlannerEngine.find(PlannerEngine.view(remoteChoice),"phone").getString("title").equals("Изменено на компьютере"),"explicit remote choice discards only chosen task queue");
  JSONObject deletion=PlannerEngine.operation(new JSONObject().put("kind","delete").put("id","phone").put("revision",1));reject(pcEdit,deletion);
  JSONObject deleted=PlannerEngine.apply(old,deletion,false);check(deleted.getJSONArray("tasks").length()==0,"offline deletion");
  reject(deleted,edit);check(PlannerEngine.find(PlannerEngine.apply(deleted,edit,true),"phone")!=null,"remote deletion keeps local conflicting edit visible");
  check(PlannerEngine.merge(PlannerEngine.apply(old,edit,false),new JSONArray().put(edit)).getJSONArray("ack").length()==1,"lost PUT response update is idempotent");
  JSONObject undone=PlannerEngine.apply(view,PlannerEngine.operation(new JSONObject().put("kind","complete").put("taskId","phone").put("date","2026-11-02").put("done",false)),false);check(undone.getJSONArray("completions").length()==0,"undo completion offline");
  try{PlannerEngine.task(PlannerEngine.copy(created).put("duration",5.5));throw new AssertionError("fractional duration accepted");}catch(Exception expected){checks++;}
  JSONObject mobile=new JSONObject().put("capturedAt","2026-11-02T17:00:00Z").put("branches",new JSONArray());JSONObject scheduleState=state(base,new JSONArray()).put("mobilePending",mobile);
  check(PlannerEngine.view(scheduleState).getJSONObject("mobile").getString("capturedAt").equals("2026-11-02T17:00:00Z"),"fresh schedule visible before upload");
  JSONObject sent=PlannerEngine.copy(base).put("mobile",mobile);
  check(!PlannerEngine.accept(scheduleState,sent,new JSONArray(),new JSONArray()).has("mobilePending"),"uploaded schedule acknowledged");
  scheduleState.put("mobilePending",new JSONObject(mobile.toString()).put("capturedAt","2026-11-02T18:00:00Z"));
  check(PlannerEngine.accept(scheduleState,sent,new JSONArray(),new JSONArray()).has("mobilePending"),"new schedule during upload is retained");
  check(PlannerEngine.find(base,"phone")==null,"engine never mutates original data");
  System.out.println("OK: "+checks+" offline queue, restart, merge, in-flight edits, conflict resolution and idempotency checks");
 }
}
