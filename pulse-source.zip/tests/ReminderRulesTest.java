package ru.pulse.omnitest;
import java.time.*;
import java.util.*;
public class ReminderRulesTest {
 static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
 public static void main(String[] args){
  long now=Instant.parse("2026-11-02T15:51:00Z").toEpochMilli();
  List<ReminderRules.Entry> zero=ReminderRules.upcoming("2026-11-02","18:56","none",0,now,day->false);
  check(zero.size()==1,"reminder=0 must schedule");
  check(zero.get(0).due==Instant.parse("2026-11-02T15:56:00Z").toEpochMilli(),"Moscow UTC+3 conversion");
  check(ReminderRules.upcoming("2026-11-02","18:56","none",0,now,day->true).isEmpty(),"completed excluded");
  check(ReminderRules.upcoming("2026-11-02","18:56","none",0,zero.get(0).due+1,day->false).isEmpty(),"past reminder excluded");
  check(ReminderRules.upcoming("2026-12-15","10:00","none",15,now,day->false).size()==1,"distant future task scheduled");
  check(ReminderRules.due("2026-11-03","00:10",15)==Instant.parse("2026-11-02T20:55:00Z").toEpochMilli(),"reminder crosses midnight");
  check(ReminderRules.occurs("2026-01-31","monthly",LocalDate.parse("2026-02-28")),"short month clamp");
  check(!ReminderRules.occurs("2026-11-02","weekdays",LocalDate.parse("2026-11-07")),"weekend excluded");
  check(ReminderRules.upcoming("2026-11-02","18:56","daily",0,now,day->false).size()==14,"recurring horizon");
  System.out.println("OK: 9 checks: zero reminder, Moscow time, completed/past, distant date, midnight, month end, weekdays, recurrence");
 }
}
