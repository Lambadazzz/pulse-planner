import ru.pulse.omnitest.CryptoCore;
public class CryptoInterop {
 public static void main(String[] a)throws Exception{
  byte[] result=a[0].equals("decrypt")?CryptoCore.decrypt(CryptoCore.bytes(a[4]),a[1],CryptoCore.bytes(a[2]),CryptoCore.bytes(a[3])):CryptoCore.encrypt(CryptoCore.bytes(a[4]),a[1],CryptoCore.bytes(a[2]),CryptoCore.bytes(a[3]));
  System.out.print(CryptoCore.b64(result));
 }
}
