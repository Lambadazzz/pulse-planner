import test from 'node:test';
import assert from 'node:assert/strict';
import {open,seal} from '../.sites-runtime/github-core.mjs';
const key='Проверочная фраза 2026!';
test('шифрование GitHub: случайные соль/IV, отдельные домены, неверная фраза и подмена',async()=>{const a=await seal({title:'Личная задача'},key),b=await seal({title:'Личная задача'},key);assert.notEqual(a.salt,b.salt);assert.notEqual(a.iv,b.iv);assert.ok(!JSON.stringify(a).includes('Личная задача'));assert.deepEqual(await open(a,key),{title:'Личная задача'});await assert.rejects(()=>open(a,'другая проверочная фраза'));await assert.rejects(()=>open(a,key,'pulse/connection/v1'));await assert.rejects(()=>open({...a,ciphertext:a.ciphertext.slice(0,-5)+'AAAAA'},key));});
globalThis.window=new EventTarget();const storage=new Map();globalThis.localStorage={getItem:k=>storage.get(k)??null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)};
const A=await import('../.sites-runtime/github-store.mjs?A'),B=await import('../.sites-runtime/github-store.mjs?B');
let blob=null,sha=0,writes=0,conflicts=0,isPrivate=true;
const original=globalThis.fetch;
globalThis.fetch=async(url,init={})=>{assert.ok(String(url).startsWith('https://api.github.com/repos/example/pulse-planner-data'));assert.equal(init.headers.Authorization,'Bearer test-token');if(String(url).endsWith('/pulse-planner-data'))return Response.json({private:isPrivate});if(init.method==='GET'){if(!blob)return new Response(null,{status:404});return Response.json({encoding:'base64',sha:String(sha),content:Buffer.from(JSON.stringify(blob)).toString('base64')},{headers:{ETag:'"'+sha+'"'}});}if(init.method==='PUT'){const body=JSON.parse(init.body);if((body.sha??null)!==(blob?String(sha):null)){conflicts++;return new Response(null,{status:409});}blob=JSON.parse(Buffer.from(body.content,'base64').toString());sha++;writes++;return Response.json({content:{sha:String(sha)}},{status:201});}throw Error('Unexpected request');};
const githubFetch=globalThis.fetch;
test('два устройства: параллельные создания не теряются, устаревшая правка отвергается',async()=>{try{const cfg={owner:'example',repo:'pulse-planner-data',token:'test-token'};await A.connect(cfg,key,true);const rememberedToken=storage.get('pulse.connection');await B.connect(cfg,key,false);const base={notes:'',date:'2026-11-02',time:'18:00',duration:30,repeat:'daily',reminder:15};const [one,two]=await Promise.all([A.api('/api/tasks','POST',{...base,title:'С компьютера'}),B.api('/api/tasks','POST',{...base,title:'С телефона'})]);let state=await A.api('/api/state');assert.equal(state.tasks.length,2);await A.api('/api/tasks','PATCH',{...one,title:'Новая версия'});await assert.rejects(()=>B.api('/api/tasks','PATCH',{...one,title:'Старая версия'}),/другом устройстве/);await B.api('/api/complete','POST',{taskId:two.id,date:'2026-11-02',done:true});state=await A.api('/api/state');assert.equal(state.completions.length,1);assert.equal(state.tasks.find(t=>t.id===one.id).title,'Новая версия');assert.ok(!JSON.stringify(blob).includes('С компьютера'));assert.ok(!rememberedToken.includes('test-token'));const before=writes;await assert.rejects(()=>B.connect(cfg,'неправильная фраза 12345',false));assert.equal(writes,before);isPrivate=false;await assert.rejects(()=>B.connect(cfg,key,false),/приватный/);assert.equal(writes,before);assert.ok(conflicts>0);}finally{globalThis.fetch=original;}});


test('ручное обновление: свежие данные GitHub, без условного кэша, ошибка сети не становится успехом',async()=>{
 let headers,offline=false;isPrivate=true;
 globalThis.fetch=async(url,init)=>{if(offline)throw new Error('offline');headers=init.headers;return githubFetch(url,init);};
 try{
  await B.connect({owner:'example',repo:'pulse-planner-data',token:'test-token'},key,false);
  const task=await B.api('/api/tasks','POST',{title:'Новая задача на другом устройстве',notes:'',date:'2026-11-02',time:'21:00',duration:30,repeat:'none',reminder:0});
  const state=await A.api('/api/refresh','POST');
  assert.ok(state.tasks.some(t=>t.id===task.id));
  assert.equal(headers['If-None-Match'],undefined);
  offline=true;await assert.rejects(()=>A.api('/api/refresh','POST'),/Нет связи с GitHub/);
 }finally{globalThis.fetch=original;}
});
