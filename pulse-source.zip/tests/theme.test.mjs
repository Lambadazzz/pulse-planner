import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
const code=await readFile(new URL('../github-app/public/theme.js',import.meta.url),'utf8');
test('ночная тема: 20:00 включительно — 06:00 исключительно, независимо от зоны устройства',()=>{
 const context=vm.createContext({Intl,Date});vm.runInContext(code,context);const at=value=>context.PulseTheme.at(new Date(value));
 assert.equal(at('2026-11-02T16:59:59Z'),'light');assert.equal(at('2026-11-02T17:00:00Z'),'dark');
 assert.equal(at('2026-11-03T02:59:59Z'),'dark');assert.equal(at('2026-11-03T03:00:00Z'),'light');
 assert.equal(at('2026-11-02T20:00:00+09:00'),'light');assert.equal(at('2026-11-02T12:00:00-05:00'),'dark');
});
test('тема обновляет HTML/meta и повторно проверяется после возврата на экран',()=>{
 const listeners={},root={dataset:{}},meta={content:''};let timer;
 const document={documentElement:root,querySelector:()=>meta,visibilityState:'visible',addEventListener:(name,fn)=>listeners[name]=fn};
 const context=vm.createContext({Intl,Date,document,setTimeout:fn=>{timer=fn;return 1;},clearTimeout:()=>{},addEventListener:(name,fn)=>listeners[name]=fn});
 vm.runInContext(code,context);context.PulseTheme.apply(new Date('2026-11-02T17:00:00Z'));assert.equal(root.dataset.theme,'dark');assert.equal(meta.content,'#18191f');
 context.PulseTheme.apply(new Date('2026-11-03T03:00:00Z'));assert.equal(root.dataset.theme,'light');assert.equal(meta.content,'#f6f6f8');
 assert.equal(typeof timer,'function');assert.equal(typeof listeners.focus,'function');assert.equal(typeof listeners.visibilitychange,'function');
});
