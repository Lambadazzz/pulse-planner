declare global {interface Window {PulseNative?:{request:(message:string)=>void};__pulseReply?:(id:string,message:string)=>void}}
export const isNative=typeof window!=='undefined'&&!!window.PulseNative;
const waiting=new Map<string,{resolve:(value:unknown)=>void;reject:(error:Error)=>void;timer:number}>();
let counter=0;
if(isNative)window.__pulseReply=(id,message)=>{const request=waiting.get(id);if(!request)return;clearTimeout(request.timer);waiting.delete(id);try{const result=JSON.parse(message);if(result.ok)request.resolve(result.value);else request.reject(new Error(result.error||'Действие не выполнено.'));}catch{request.reject(new Error('Не удалось прочитать ответ приложения.'));}};
export function nativeCall<T=Record<string,unknown>>(method:string,body:unknown={}):Promise<T>{
 return new Promise((resolve,reject)=>{if(!window.PulseNative){reject(new Error('Откройте Android-приложение.'));return;}const id=`n${Date.now()}-${++counter}`;const timer=window.setTimeout(()=>{waiting.delete(id);reject(new Error('Действие ещё не подтвердилось. Обновите экран перед повтором.'));},90000);waiting.set(id,{resolve:resolve as (value:unknown)=>void,reject,timer});try{window.PulseNative.request(JSON.stringify({id,method,body}));}catch{clearTimeout(timer);waiting.delete(id);reject(new Error('Не удалось передать действие Android.'));}});
}
