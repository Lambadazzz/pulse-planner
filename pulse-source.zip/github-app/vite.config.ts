import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import path from 'node:path';
export default defineConfig({root:path.resolve(import.meta.dirname),base:'./',plugins:[react()],publicDir:'public',build:{outDir:'dist',assetsDir:'',emptyOutDir:true},server:{host:'127.0.0.1',port:5174,fs:{allow:[path.resolve(import.meta.dirname,'..')]}}});
